declare const _default: import("clientnode").PlainObject;
export default _default;
