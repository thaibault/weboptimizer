// #!/usr/bin/env babel-node
// -*- coding: utf-8 -*-
/** @module browser */
'use strict';

/* !
    region header
    Copyright Torben Sickert (info["~at~"]torben.website) 16.12.2012

    License
    -------

    This library written by Torben Sickert stand under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/
// region imports
var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getInitializedBrowser = exports["default"] = exports.browser = void 0;
var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));
var _clientnode = require("clientnode");
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t["return"] || t["return"](); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function _interopRequireWildcard(e, t) { if ("function" == typeof WeakMap) var r = new WeakMap(), n = new WeakMap(); return (_interopRequireWildcard = function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var o, i, f = { __proto__: null, "default": e }; if (null === e || "object" != _typeof(e) && "function" != typeof e) return f; if (o = t ? n : r) { if (o.has(e)) return o.get(e); o.set(e, f); } for (var _t in e) "default" !== _t && {}.hasOwnProperty.call(e, _t) && ((i = (o = Object.defineProperty) && Object.getOwnPropertyDescriptor(e, _t)) && (i.get || i.set) ? o(f, _t, i) : f[_t] = e[_t]); return f; })(e, t); }
// endregion
// region declaration

//  endregion
//  region variables
var onCreatedListener = [];
var browser = exports.browser = {
  debug: false,
  domContentLoaded: false,
  DOM: null,
  initialized: false,
  instance: null,
  window: null,
  windowLoaded: false
};
// endregion
// region ensure presence of common browser environment
if (typeof TARGET_TECHNOLOGY === 'undefined' || TARGET_TECHNOLOGY === 'node')
  /*
      NOTE: We use an asynchronous wrapper method to initialize
      "browser.initialized" at module loading time.
  */
  (0, _asyncToGenerator2["default"])(/*#__PURE__*/_regenerator["default"].mark(function _callee() {
    var _yield$Promise$all, _yield$Promise$all2, _yield$Promise$all2$, JSDOM, VirtualConsoleImplementation, path, virtualConsole, _iterator, _step, name, render, filePath, ejsLoader, content;
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          _context.next = 2;
          return Promise.all([Promise.resolve().then(function () {
            return _interopRequireWildcard(require('jsdom'));
          }), Promise.resolve().then(function () {
            return _interopRequireWildcard(require('path'));
          })]);
        case 2:
          _yield$Promise$all = _context.sent;
          _yield$Promise$all2 = (0, _slicedToArray2["default"])(_yield$Promise$all, 2);
          _yield$Promise$all2$ = _yield$Promise$all2[0];
          JSDOM = _yield$Promise$all2$.JSDOM;
          VirtualConsoleImplementation = _yield$Promise$all2$.VirtualConsole;
          path = _yield$Promise$all2[1];
          virtualConsole = new VirtualConsoleImplementation();
          _iterator = _createForOfIteratorHelper(_clientnode.CONSOLE_METHODS);
          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              name = _step.value;
              virtualConsole.on(name, console[name].bind(console));
            }
          } catch (err) {
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
          virtualConsole.on('error', function (error) {
            if (!browser.debug && ['XMLHttpRequest', 'resource loading'].includes(error.type)) console.warn("Loading resource failed: ".concat(error.toString(), "."));else console.error(error.stack, error.detail);
          });
          render = function render(template) {
            browser.DOM = JSDOM;
            browser.initialized = true;
            browser.instance = new browser.DOM(template, {
              beforeParse: function beforeParse(window) {
                var _ref2;
                // We want to use it in a polymorphic way.
                browser.window = (_ref2 = global.window) !== null && _ref2 !== void 0 ? _ref2 : window;
                window.document.addEventListener('DOMContentLoaded', function () {
                  /*
                      Move template results into global
                      pre-defined dom.
                  */
                  if (global.window) {
                    var _iterator2 = _createForOfIteratorHelper(['head', 'body']),
                      _step2;
                    try {
                      for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                        var type = _step2.value;
                        global.window.document[type].innerHTML = window.document[type].innerHTML;
                      }
                    } catch (err) {
                      _iterator2.e(err);
                    } finally {
                      _iterator2.f();
                    }
                  }
                  browser.domContentLoaded = true;
                });
                window.addEventListener('load', function () {
                  /*
                      NOTE: Maybe we have miss the "DOMContentLoaded"
                      event caused by a race condition.
                  */
                  browser.domContentLoaded = browser.windowLoaded = true;
                });
                var _iterator3 = _createForOfIteratorHelper(onCreatedListener),
                  _step3;
                try {
                  for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
                    var callback = _step3.value;
                    callback();
                  }
                } catch (err) {
                  _iterator3.e(err);
                } finally {
                  _iterator3.f();
                }
              },
              resources: 'usable',
              runScripts: 'dangerously',
              url: 'http://localhost',
              virtualConsole: virtualConsole
            });
          };
          if (!(typeof NAME === 'undefined' || NAME === 'webOptimizer')) {
            _context.next = 26;
            break;
          }
          filePath = path.join(__dirname, 'index.html.ejs');
          /*
              NOTE: We load dependencies now to avoid having file imports
              after test runner has finished to isolate the environment.
          */
          _context.next = 17;
          return Promise.resolve().then(function () {
            return _interopRequireWildcard(require('./ejsLoader'));
          });
        case 17:
          ejsLoader = _context.sent["default"];
          _context.next = 20;
          return Promise.resolve().then(function () {
            return _interopRequireWildcard(require('fs'));
          });
        case 20:
          _context.next = 22;
          return _context.sent.promises.readFile(filePath, {
            encoding: 'utf-8'
          });
        case 22:
          content = _context.sent;
          render(ejsLoader.bind({
            resourcePath: filePath
          })(content));
          _context.next = 31;
          break;
        case 26:
          _context.t0 = render;
          _context.next = 29;
          return Promise.resolve().then(function () {
            return _interopRequireWildcard(require('webOptimizerDefaultTemplateFilePath'));
          });
        case 29:
          _context.t1 = _context.sent;
          (0, _context.t0)(_context.t1);
        case 31:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }))()["catch"](function (error) {
    console.error(error);
  });else {
  browser.initialized = true;
  browser.window = window;
  window.document.addEventListener('DOMContentLoaded', function () {
    browser.domContentLoaded = true;
  });
  window.addEventListener('load', function () {
    browser.windowLoaded = true;
  });
  void (0, _clientnode.timeout)(function () {
    var _iterator4 = _createForOfIteratorHelper(onCreatedListener),
      _step4;
    try {
      for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
        var callback = _step4.value;
        callback();
      }
    } catch (err) {
      _iterator4.e(err);
    } finally {
      _iterator4.f();
    }
  });
}
// endregion
/**
 * Provides a generic browser api in node or web contexts.
 * @param replaceWindow - Indicates whether a potential existing window object
 * should be replaced or not.
 * @returns Determined environment.
 */
var getInitializedBrowser = exports.getInitializedBrowser = /*#__PURE__*/function () {
  var _ref3 = (0, _asyncToGenerator2["default"])(/*#__PURE__*/_regenerator["default"].mark(function _callee2() {
    var replaceWindow,
      resolvePromise,
      promise,
      wrappedCallback,
      _args2 = arguments;
    return _regenerator["default"].wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          replaceWindow = _args2.length > 0 && _args2[0] !== undefined ? _args2[0] : true;
          promise = new Promise(function (resolve) {
            resolvePromise = resolve;
          });
          /*
              NOTE: We have to define window globally before anything is loaded to
              ensure that all future instances share the same window object.
          */
          wrappedCallback = function wrappedCallback() {
            if (replaceWindow && typeof global !== 'undefined' && global !== browser.window) global.window = browser.window;
            resolvePromise(browser);
          };
          if (browser.initialized) wrappedCallback();else onCreatedListener.push(wrappedCallback);
          return _context2.abrupt("return", promise);
        case 5:
        case "end":
          return _context2.stop();
      }
    }, _callee2);
  }));
  return function getInitializedBrowser() {
    return _ref3.apply(this, arguments);
  };
}();
var _default = exports["default"] = getInitializedBrowser;
