// #!/usr/bin/env babel-node
// -*- coding: utf-8 -*-
/** @module ejsLoader */
'use strict';

/* !
    region header
    Copyright Torben Sickert (info["~at~"]torben.website) 16.12.2012

    License
    -------

    This library written by Torben Sickert stand under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/
// region imports
var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.loader = exports["default"] = void 0;
var _construct2 = _interopRequireDefault(require("@babel/runtime/helpers/construct"));
var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime/helpers/toConsumableArray"));
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _core = require("@babel/core");
var _babelPresetMinify = _interopRequireDefault(require("babel-preset-minify"));
var _clientnode = require("clientnode");
var _ejs = _interopRequireDefault(require("ejs"));
var _fs = require("fs");
var _htmlMinifier = require("html-minifier");
var _path = require("path");
var _configurator = _interopRequireDefault(require("./configurator"));
var _helper = require("./helper");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2["default"])(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
// endregion
// region types

// endregion
var configuration = (0, _configurator["default"])();
/**
 * Main transformation function.
 * @param source - Input string to transform.
 * @returns Transformed string.
 */
var loader = exports.loader = function loader(source) {
  var _ref,
    _this = this,
    _givenOptions$compile;
  var givenOptions = (0, _clientnode.convertSubstringInPlainObject)((0, _clientnode.extend)(true, {
    compiler: {},
    compileSteps: 2,
    compress: {
      html: {},
      javaScript: {}
    },
    context: './',
    debug: false,
    extensions: {
      file: {
        external: [],
        internal: ['.js', '.json', '.css', '.svg', '.png', '.jpg', '.gif', '.ico', '.html', '.eot', '.ttf', '.woff', '.woff2']
      }
    },
    module: {
      aliases: {},
      replacements: {}
    }
  }, this.getOptions ? this.getOptions() : (_ref = this.query) !== null && _ref !== void 0 ? _ref : {}), /#%%%#/g, '!');
  var _compile = function compile(template) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : givenOptions.compiler;
    var compileSteps = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 2;
    return function () {
      var locals = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      options = _objectSpread({
        filename: template
      }, options);
      var givenLocals = [].concat(locals);
      var require = function require(request) {
        var _givenOptions$module, _givenOptions$module2, _givenOptions$extensi;
        var nestedLocals = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
        var template = request.replace(/^(.+)\?[^?]+$/, '$1');
        var queryMatch = /^[^?]+\?(.+)$/.exec(request);
        if (queryMatch) {
          var evaluated = (0, _clientnode.evaluate)(queryMatch[1], {
            compile: _compile,
            locals: locals,
            request: request,
            source: source,
            template: template
          });
          if (evaluated.error) console.warn('Error occurred during processing given query: ' + evaluated.error);else if (evaluated.result) (0, _clientnode.extend)(true, nestedLocals, evaluated.result);
        }
        var nestedOptions = (0, _clientnode.copy)(options);
        delete nestedOptions.client;
        nestedOptions = (0, _clientnode.extend)(true, {
          encoding: configuration.encoding
        }, nestedOptions, nestedLocals.options || {}, options !== null && options !== void 0 ? options : {});
        if (nestedOptions.isString) return _compile(template, nestedOptions)(nestedLocals);
        var templateFilePath = (0, _helper.determineModuleFilePath)(template, (_givenOptions$module = givenOptions.module) === null || _givenOptions$module === void 0 ? void 0 : _givenOptions$module.aliases, (_givenOptions$module2 = givenOptions.module) === null || _givenOptions$module2 === void 0 ? void 0 : _givenOptions$module2.replacements, {
          file: ((_givenOptions$extensi = givenOptions.extensions) === null || _givenOptions$extensi === void 0 ? void 0 : _givenOptions$extensi.file.internal) || []
        }, givenOptions.context, configuration.path.source.asset.base, configuration.path.ignore, configuration.module.directoryNames, configuration["package"].main.fileNames, configuration["package"].main.propertyNames, configuration["package"].aliasPropertyNames, configuration.encoding);
        if (templateFilePath) {
          if (_this.addDependency) _this.addDependency(templateFilePath);
          /*
              NOTE: If there aren't any locals options or variables and
              file doesn't seem to be an ejs template we simply load
              included file content.
          */
          if (queryMatch || templateFilePath.endsWith('.ejs')) return _compile(templateFilePath, nestedOptions)(nestedLocals);
          return (0, _fs.readFileSync)(templateFilePath, {
            encoding: nestedOptions.encoding
          });
        }
        throw new Error("Given template file \"".concat(template, "\" couldn't be resolved."));
      };
      var compressHTML = function compressHTML(content) {
        var _givenOptions$compres;
        return (_givenOptions$compres = givenOptions.compress) !== null && _givenOptions$compres !== void 0 && _givenOptions$compres.html ? (0, _htmlMinifier.minify)(content, (0, _clientnode.extend)(true, {
          caseSensitive: true,
          collapseInlineTagWhitespace: true,
          collapseWhitespace: true,
          conservativeCollapse: true,
          minifyCSS: true,
          minifyJS: true,
          processScripts: ['text/ng-template', 'text/x-handlebars-template'],
          removeAttributeQuotes: true,
          removeComments: true,
          removeRedundantAttributes: true,
          removeScriptTypeAttributes: true,
          removeStyleLinkTypeAttributes: true,
          sortAttributes: true,
          sortClassName: true,
          /*
              NOTE: Avoids whitespace around placeholder in
              tags.
          */
          trimCustomFragments: true,
          useShortDoctype: true
        }, givenOptions.compress.html)) : content;
      };
      var result = template;
      var isString = Boolean(options.isString);
      delete options.isString;
      var stepLocals;
      var scope = {};
      var originalScopeNames = [];
      var scopeNames = [];
      for (var step = 1; step <= compileSteps; step += 1) {
        // On every odd compile step we have to determine the environment.
        if (step % 2) {
          // region determine scope
          var localsIndex = Math.round(step / 2) - 1;
          stepLocals = localsIndex < givenLocals.length ? givenLocals[localsIndex] : {};
          scope = {};
          if (step < 3 && 1 < compileSteps) scope = _objectSpread(_objectSpread({}, _clientnode.UTILITY_SCOPE), {}, {
            configuration: configuration,
            include: require,
            require: require
          }, Array.isArray(stepLocals) ? {} : stepLocals);else if (!Array.isArray(stepLocals)) scope = stepLocals;
          originalScopeNames = Array.isArray(stepLocals) ? stepLocals : Object.keys(scope);
          scopeNames = originalScopeNames.map(function (name) {
            return (0, _clientnode.convertToValidVariableName)(name);
          });
          // endregion
        }
        if (typeof result === 'string') {
          var filePath = isString ? options.filename : result;
          if (filePath && (0, _path.extname)(filePath) === '.js' && _clientnode.currentRequire) result = (0, _clientnode.currentRequire)(filePath);else {
            if (!isString) {
              var encoding = configuration.encoding;
              if (typeof options.encoding === 'string') encoding = options.encoding;
              result = (0, _fs.readFileSync)(result, {
                encoding: encoding
              });
            }
            if (step === compileSteps) result = compressHTML(result);
            if (options.strict || !options._with)
              // NOTE: Needed to manipulate code after compiling.
              options.client = true;
            result = _ejs["default"].compile(result, options);

            /*
                Provide all scope names when "_with" options isn't
                enabled
            */
            if (options.strict || !options._with) {
              var localsName = options.localsName || 'locals';
              while (scopeNames.includes(localsName)) localsName = "_".concat(localsName);

              /* eslint-disable @typescript-eslint/no-implied-eval */
              result = (0, _construct2["default"])(Function, (0, _toConsumableArray2["default"])(scopeNames).concat([localsName, "return ".concat(result.toString(), "(") + "".concat(localsName, ",") + "".concat(localsName, ".escapeFn,") + "".concat(localsName, ".include,") + "".concat(localsName, ".rethrow)")]));
              /* eslint-enable @typescript-eslint/no-implied-eval */
            }
          }
        } else result = compressHTML(!options.strict && options._with ? result(scope, scope.escapeFn, scope.include) : result.apply(void 0, (0, _toConsumableArray2["default"])(originalScopeNames.map(function (name) {
          return scope[name];
        }).concat(!options.strict && options._with ? [] : scope))));
      }
      if (compileSteps % 2) {
        var _givenOptions$compres2, _givenOptions$compres3, _givenOptions$compres4, _givenOptions$compres5;
        var code = "module.exports = ".concat(result.toString());
        var processed = (0, _core.transformSync)(code, {
          ast: false,
          babelrc: false,
          comments: !((_givenOptions$compres2 = givenOptions.compress) !== null && _givenOptions$compres2 !== void 0 && _givenOptions$compres2.javaScript),
          compact: Boolean((_givenOptions$compres3 = givenOptions.compress) === null || _givenOptions$compres3 === void 0 ? void 0 : _givenOptions$compres3.javaScript),
          filename: options.filename || 'unknown',
          minified: Boolean((_givenOptions$compres4 = givenOptions.compress) === null || _givenOptions$compres4 === void 0 ? void 0 : _givenOptions$compres4.javaScript),
          presets: (_givenOptions$compres5 = givenOptions.compress) !== null && _givenOptions$compres5 !== void 0 && _givenOptions$compres5.javaScript ? [[_babelPresetMinify["default"], givenOptions.compress.javaScript]] : [],
          sourceMaps: false,
          sourceType: 'script'
        });
        if (typeof (processed === null || processed === void 0 ? void 0 : processed.code) === 'string') code = processed.code;
        return "".concat(options.strict ? "'use strict';\n" : '').concat(code);
      }
      if (typeof result === 'string') {
        result = result.replace(new RegExp("<script +processing-workaround *" + "(?: = *(?: \" *\"|' *') *)?>([\\s\\S]*?)</ *script *>", 'ig'), '$1').replace(new RegExp("<script +processing(-+)-workaround *" + "(?: = *(?: \" *\"|' *') *)?>([\\s\\S]*?)</ *script *>", 'ig'), '<script processing$1workaround>$2</script>');
        return result;
      }
      return '';
    };
  };
  return _compile(source, _objectSpread(_objectSpread({}, givenOptions.compiler), {}, {
    client: Boolean(((_givenOptions$compile = givenOptions.compileSteps) !== null && _givenOptions$compile !== void 0 ? _givenOptions$compile : 2) % 2),
    compileDebug: givenOptions.debug,
    debug: givenOptions.debug,
    filename: this.resourcePath || 'unknown',
    isString: true
  }), givenOptions.compileSteps)(givenOptions.locals || {});
};
var _default = exports["default"] = loader;
