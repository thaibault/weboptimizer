// #!/usr/bin/env babel-node
// -*- coding: utf-8 -*-
/** @module webpackConfigurator */
'use strict';

/* !
    region header
    Copyright Torben Sickert (info["~at~"]torben.website) 16.12.2012

    License
    -------

    This library written by Torben Sickert stand under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/
// region imports
var _clientnode = require("clientnode");
var _util = require("util");
_clientnode.globalContext.TextEncoder = _util.TextEncoder;
_clientnode.globalContext.TextDecoder = _util.TextDecoder;
try {
  if (eval('require')('jest-canvas-mock')) console.info('Canvas mocking module loaded.');
} catch (error) {
  // Do nothing.
}
// region vim modline
// vim: set tabstop=4 shiftwidth=4 expandtab:
// vim: foldmethod=marker foldmarker=region,endregion:
// endregion
