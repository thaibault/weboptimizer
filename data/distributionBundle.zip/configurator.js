// #!/usr/bin/env babel-node
// -*- coding: utf-8 -*-
/** @module configurator */
'use strict';

/* !
    region header
    Copyright Torben Sickert (info["~at~"]tsickert.com) 16.12.2012

    License
    -------

    This library written by Torben Sickert stands under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/
// region imports
import { convertCircularObjectToJSON, copy, evaluateAsyncDynamicData, evaluateDynamicData, extend, getUTCTimestamp, importFilesystemAPI, isFile, isObject, isPlainObject, Logger, MAXIMAL_NUMBER_OF_ITERATIONS, modifyObject, optionalImport, parseEncodedObject, removeKeyPrefixes, UTILITY_SCOPE } from 'clientnode';
import fileSystemSynchronous from 'fs';
import fileSystem, { lstat, readFile, unlink } from 'fs/promises';
import path, { basename, dirname, join, resolve } from 'path';
import { determineAssetType, determineModuleFilePath, determineModuleLocations, resolveAutoInjection, resolveBuildConfigurationFilePaths, resolveModulesInFolders, normalizeGivenInjection, normalizePaths } from "./helper.js";
import packageConfiguration from './package.json' with { type: 'json' };
import { SubConfigurationTypes } from "./type.js";
// endregion
const {
  configuration: metaConfiguration
} = packageConfiguration;
export let loadedConfiguration = null;
export const log = new Logger({
  name: 'weboptimizer.configurator'
});

// Wait until optional filesystem modules have been loaded.
await importFilesystemAPI();

/**
 * Main entry point to determine current configuration.
 * @param context - Location from where to build current application.
 * @param currentWorkingDirectory - Current working directory to use as
 * reference.
 * @param commandLineArguments - Arguments to take into account.
 * @param webOptimizerPath - Current optimizer context path.
 * @param environment - Environment variables to take into account.
 * @returns Nothing.
 */
export const load = async (context, currentWorkingDirectory = process.cwd(), commandLineArguments = process.argv, webOptimizerPath = import.meta.dirname,
/*
    NOTE: We have to avoid that some pre-processor removes this
    assignment.
*/
// eslint-disable-next-lien no-eval
environment = eval('process.env')) => {
  // region determine application context location
  if (context) metaConfiguration.default.path.context = context;else {
    /*
        To assume to go two folder up from this file until there is no
        "node_modules" parent folder is usually resilient again dealing
        with projects where current working directory isn't the projects
        directory and this library is located as a nested dependency.
    */
    metaConfiguration.default.path.context = webOptimizerPath;
    for (let level = 0; level < MAXIMAL_NUMBER_OF_ITERATIONS.value; level++) {
      metaConfiguration.default.path.context = resolve(metaConfiguration.default.path.context, '../../');
      if (basename(dirname(metaConfiguration.default.path.context)) !== 'node_modules') break;
    }
    if (basename(dirname(currentWorkingDirectory)) === 'node_modules' || basename(dirname(currentWorkingDirectory)) === '.staging' && basename(dirname(dirname(currentWorkingDirectory))) === 'node_modules') {
      /*
          NOTE: If we are dealing was a dependency project use current
          directory as context.
      */
      metaConfiguration.default.path.context = currentWorkingDirectory;
      metaConfiguration.default.contextType = 'dependency';
    } else
      /*
          NOTE: If the current working directory references this file via
          a linked "node_modules" folder using current working directory
          as context is a better assumption than two folders up the
          hierarchy.
      */
      try {
        if ((await lstat(join(currentWorkingDirectory, 'node_modules'))).isSymbolicLink()) metaConfiguration.default.path.context = currentWorkingDirectory;
      } catch {
        // Continue regardless of error.
      }
  }
  // endregion
  // region load application specific configuration
  let specificConfiguration = {};
  try {
    specificConfiguration = (await optionalImport(join(metaConfiguration.default.path.context, 'package.json'), {
      with: {
        type: 'json'
      }
    })).default;
  } catch {
    metaConfiguration.default.path.context = currentWorkingDirectory;
  }
  // endregion
  // region determine application name and web optimizer configuration
  const name = typeof specificConfiguration.name === 'string' ? specificConfiguration.name : typeof specificConfiguration.webOptimizer?.name === 'string' ? specificConfiguration.webOptimizer?.name : 'mockup';
  specificConfiguration = specificConfiguration.webOptimizer || {};
  specificConfiguration.name = name;
  // endregion
  // region determine debug mode
  // NOTE: Given node command line arguments results in "npm_config_*"
  // environment variables.
  let debug = metaConfiguration.default.debug;
  if (typeof specificConfiguration.debug === 'boolean') debug = specificConfiguration.debug;else if (environment.npm_config_dev === 'true' || typeof environment.NODE_ENV === 'string' && ['debug', 'dev', 'development'].includes(environment.NODE_ENV)) debug = true;
  if (debug) environment.NODE_ENV = 'development';
  // endregion
  // region loading default configuration
  metaConfiguration.default.path.context += '/';
  // Merges final default configuration object depending on given target
  // environment.
  const libraryConfiguration = metaConfiguration.library;
  let configuration;
  if (debug) configuration = extend(true, modifyObject(metaConfiguration.default, metaConfiguration.debug), metaConfiguration.debug);else configuration = metaConfiguration.default;
  configuration.debug = debug;
  if (typeof configuration.library === 'object') extend(true, modifyObject(libraryConfiguration, configuration.library), configuration.library);
  if (configuration.library && specificConfiguration.library !== false) {
    const modifiedConfiguration = modifyObject(configuration, libraryConfiguration);
    configuration = extend(true,
    /*
        NOTE: We have to copy both objects otherwise the
        substucture under "path" is not extended as expected.
    */
    copy(modifiedConfiguration), copy(libraryConfiguration));
  }

  // endregion
  // region merging and evaluating task specific and dynamic configurations
  /// region load additional dynamically given configuration
  let count = 0;
  let filePath = null;
  for (let iteration = 0; iteration < MAXIMAL_NUMBER_OF_ITERATIONS.value; iteration++) {
    const newFilePath = `${configuration.path.context}.dynamicConfiguration-` + `${String(count)}.json`;
    if (!(await isFile(newFilePath))) break;
    filePath = newFilePath;
    count += 1;
  }
  let runtimeInformation = {
    givenCommandLineArguments: commandLineArguments
  };
  if (filePath) {
    const fileContent = await readFile(filePath, {
      encoding: configuration.encoding
    });
    runtimeInformation = JSON.parse(fileContent);
    await unlink(filePath);
  }
  //// region task specific configuration
  ///// region apply task type specific configuration
  if (runtimeInformation.givenCommandLineArguments.length > 2) for (const type of SubConfigurationTypes) if (runtimeInformation.givenCommandLineArguments[2] === type || debug && type === 'debug' || type === 'test' && runtimeInformation.givenCommandLineArguments[2].startsWith('test:') && runtimeInformation.givenCommandLineArguments[2] !== 'test:browser') for (const configurationTarget of [configuration, specificConfiguration]) if (isPlainObject(configurationTarget[type])) extend(true, modifyObject(configurationTarget, configurationTarget[type]), configurationTarget[type]);
  ///// endregion
  ///// region clear task type specific configurations
  for (const type of SubConfigurationTypes) for (const configurationTarget of [configuration, specificConfiguration]) if (Object.prototype.hasOwnProperty.call(configurationTarget, type) && typeof configurationTarget[type] === 'object') delete configurationTarget[type];
  ///// endregion
  //// endregion
  /// endregion
  extend(true, modifyObject(modifyObject(configuration, specificConfiguration), runtimeInformation), specificConfiguration, runtimeInformation);
  let result = null;
  if (runtimeInformation.givenCommandLineArguments.length > 3) result = parseEncodedObject(runtimeInformation.givenCommandLineArguments[runtimeInformation.givenCommandLineArguments.length - 1], configuration, 'configuration');
  if (isObject(result)) {
    if (Object.prototype.hasOwnProperty.call(result, '__reference__')) {
      const referenceNames = [].concat(result.__reference__);
      delete result.__reference__;
      for (const name of referenceNames) if (Object.prototype.hasOwnProperty.call(configuration, name)) extend(true, result, configuration[name]);else if (await isFile(name)) extend(true, result, JSON.parse(await readFile(name, configuration.encoding)));else void log.warn(`Given dynamic referenced configuration "${name}"`, 'could not be resolved.');
    }
    extend(true, modifyObject(configuration, result), result);
  }
  // Removing comments (default key name to delete is "#").
  configuration = removeKeyPrefixes(configuration);
  // endregion
  /// region build absolute paths
  configuration.path.base = resolve(configuration.path.context, configuration.path.base);
  for (const [key, path] of Object.entries(configuration.path)) if (!['base', 'configuration'].includes(key)) if (typeof path === 'string') configuration.path[key] = resolve(configuration.path.base, path) + '/';else if (isPlainObject(path)) {
    if (Object.prototype.hasOwnProperty.call(path, 'base')) configuration.path[key].base = resolve(configuration.path.base, path.base);
    for (const [subKey, subPath] of Object.entries(path)) if (!['base', 'public'].includes(subKey) && typeof subPath === 'string') path[subKey] = resolve(path.base, subPath) + '/';else if (subKey !== 'options' && isPlainObject(subPath)) {
      subPath.base = resolve(path.base, subPath.base);
      for (const [subSubKey, subSubPath] of Object.entries(subPath)) if (subSubKey !== 'base' && typeof subSubPath === 'string') subPath[subSubKey] = resolve(subPath.base, subSubPath) + '/';
    }
  }
  /// endregion
  // region evaluate dynamic configuration structures
  const now = new Date();
  /*
      NOTE: The configuration is not yet fully resolved but will be
      transformed in place in the following lines of code.
  */
  const evaluationOptions = {
    scope: {
      ...UTILITY_SCOPE,
      currentPath: currentWorkingDirectory,
      fs: fileSystem,
      packageConfiguration,
      path,
      webOptimizerPath,
      now,
      nowUTCTimestamp: getUTCTimestamp(now)
    }
  };
  const resolvedConfiguration = await evaluateAsyncDynamicData(evaluateDynamicData(configuration, {
    ...evaluationOptions,
    scope: {
      ...evaluationOptions.scope,
      fs: fileSystemSynchronous
    }
  }), evaluationOptions);
  // endregion
  // region consolidate file specific build configuration
  // Apply default file level build configurations to all file type specific
  // ones.
  const defaultConfiguration = resolvedConfiguration.buildContext.types.default;
  delete resolvedConfiguration.buildContext.types.default;
  for (const [type, context] of Object.entries(resolvedConfiguration.buildContext.types)) resolvedConfiguration.buildContext.types[type] = extend(true, copy(defaultConfiguration), extend(true, {
    extension: type
  }, context, {
    type
  }));
  // endregion
  // region resolve module location and which asset types are needed
  resolvedConfiguration.module.locations = determineModuleLocations(resolvedConfiguration.injection.entry.normalized, resolvedConfiguration.module.aliases, resolvedConfiguration.module.replacements.normal, {
    file: resolvedConfiguration.extensions.file.internal
  }, resolvedConfiguration.path.context, resolvedConfiguration.path.source.asset.base);
  resolvedConfiguration.injection = resolveAutoInjection(resolvedConfiguration.injection, resolveBuildConfigurationFilePaths(resolvedConfiguration.buildContext.types, resolvedConfiguration.path.source.asset.base, normalizePaths(resolvedConfiguration.path.ignore.concat(resolvedConfiguration.module.directoryNames, resolvedConfiguration.loader.directoryNames).map(filePath => resolve(resolvedConfiguration.path.context, filePath)).filter(filePath => !resolvedConfiguration.path.context.startsWith(filePath))), resolvedConfiguration.package.main.fileNames), resolvedConfiguration.module.aliases, resolvedConfiguration.module.replacements.normal, resolvedConfiguration.extensions, resolvedConfiguration.path.context, resolvedConfiguration.path.source.asset.base, resolvedConfiguration.path.ignore);
  const givenInjection = resolvedConfiguration.injection.entry;
  resolvedConfiguration.injection.entry = {
    given: givenInjection,
    normalized: resolveModulesInFolders(normalizeGivenInjection(givenInjection), resolvedConfiguration.module.aliases, resolvedConfiguration.module.replacements.normal, resolvedConfiguration.path.context, resolvedConfiguration.path.source.asset.base, resolvedConfiguration.path.ignore.concat(resolvedConfiguration.module.directoryNames, resolvedConfiguration.loader.directoryNames).map(filePath => resolve(resolvedConfiguration.path.context, filePath)).filter(filePath => !resolvedConfiguration.path.context.startsWith(filePath)))
  };
  resolvedConfiguration.needed = {
    javaScript: configuration.debug && ['serve', 'test:browser'].includes(resolvedConfiguration.givenCommandLineArguments[2])
  };

  /// region determine which asset types are needed
  for (const chunk of Object.values(resolvedConfiguration.injection.entry.normalized)) for (const moduleID of chunk) {
    const filePath = determineModuleFilePath(moduleID, resolvedConfiguration.module.aliases, resolvedConfiguration.module.replacements.normal, {
      file: resolvedConfiguration.extensions.file.internal
    }, resolvedConfiguration.path.context,
    /*
        NOTE: We don't use
        "resolvedConfiguration.path.source.asset.base" because we
        already have resolved all module ids.
    */
    '', resolvedConfiguration.path.ignore, resolvedConfiguration.module.directoryNames, resolvedConfiguration.package.main.fileNames, resolvedConfiguration.package.main.propertyNames, resolvedConfiguration.package.aliasPropertyNames, resolvedConfiguration.encoding);
    let type;
    if (filePath) type = determineAssetType(filePath, resolvedConfiguration.buildContext.types, resolvedConfiguration.path);else throw new Error(`Given request "${moduleID}" couldn't be resolved.`);
    if (type) resolvedConfiguration.needed[type] = true;
  }
  /// endregion
  // endregion
  // region adding special aliases
  /*
      NOTE: This alias couldn't be set in the "package.json" file since this
      would result in an endless loop.
  */
  resolvedConfiguration.loader.aliases.webOptimizerDefaultTemplateFileLoader = '';
  for (const loader of Array.isArray(resolvedConfiguration.files.defaultHTML.template.use) ? resolvedConfiguration.files.defaultHTML.template.use : [resolvedConfiguration.files.defaultHTML.template.use]) {
    if (resolvedConfiguration.loader.aliases.webOptimizerDefaultTemplateFileLoader) resolvedConfiguration.loader.aliases.webOptimizerDefaultTemplateFileLoader += '!';
    resolvedConfiguration.loader.aliases.webOptimizerDefaultTemplateFileLoader += loader.loader;
    if (loader.options) resolvedConfiguration.loader.aliases.webOptimizerDefaultTemplateFileLoader += '?' + convertCircularObjectToJSON(loader.options);
  }
  resolvedConfiguration.module.aliases.webOptimizerDefaultTemplateFilePath = resolvedConfiguration.files.defaultHTML.template.filePath;
  // endregion
  // region apply HTML webpack plugin workarounds
  /*
      NOTE: Provides a workaround to handle a bug with chained loader
      configurations.
  */
  for (const htmlConfiguration of resolvedConfiguration.files.html) {
    extend(true, htmlConfiguration, resolvedConfiguration.files.defaultHTML);
    htmlConfiguration.template.request = htmlConfiguration.template.filePath;
    if (htmlConfiguration.template.filePath !== resolvedConfiguration.files.defaultHTML.template.filePath && htmlConfiguration.template.options) {
      const requestString = new String(htmlConfiguration.template.request + convertCircularObjectToJSON(htmlConfiguration.template.options));
      requestString.replace = (value => () => value)(htmlConfiguration.template.filePath);
      htmlConfiguration.template.request = requestString;
    }
  }
  // endregion
  return resolvedConfiguration;
};
/**
 * Get cached or determined configuration object.
 * @returns Nothing.
 */
export const get = async () => {
  if (!loadedConfiguration) loadedConfiguration = await load();
  return loadedConfiguration;
};
export default get;
