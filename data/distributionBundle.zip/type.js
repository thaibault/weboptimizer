// #!/usr/bin/env babel-node
// -*- coding: utf-8 -*-
/** @module type */
'use strict';

/* !
    region header
    Copyright Torben Sickert (info["~at~"]tsickert.com) 16.12.2012

    License
    -------

    This library written by Torben Sickert stands under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/
// region imports
// endregion
// region exports
/// region generic
/// endregion
/// region injection
/// endregion
/// region configuration
// region plugins
// endregion
//// region path
//// endregion
//// region build
export const SubConfigurationTypes = ['debug', 'document', 'test', 'test:browser'];
export const TaskTypes = ['build', 'serve', ...SubConfigurationTypes];
//// endregion
//// region loader

//// endregion

/// endregion
// NOTE: Not yet defined in webpack types.

// endregion
