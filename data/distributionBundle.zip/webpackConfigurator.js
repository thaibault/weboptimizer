// #!/usr/bin/env babel-node
// -*- coding: utf-8 -*-
/** @module webpackConfigurator */
'use strict';

/* !
    region header
    Copyright Torben Sickert (info["~at~"]torben.website) 16.12.2012

    License
    -------

    This library written by Torben Sickert stand under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/
// region imports
var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.webpackConfiguration = exports.optionalRequire = exports["default"] = void 0;
var _construct2 = _interopRequireDefault(require("@babel/runtime/helpers/construct"));
var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime/helpers/toConsumableArray"));
var _typeof2 = _interopRequireDefault(require("@babel/runtime/helpers/typeof"));
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _clientnode = require("clientnode");
var _path = require("path");
var _util = _interopRequireDefault(require("util"));
var _webpack = require("webpack");
var _webpackSources = require("webpack-sources");
var _configurator = _interopRequireDefault(require("./configurator"));
var _helper = require("./helper");
var _InPlaceAssetsIntoHTML = _interopRequireDefault(require("./plugins/InPlaceAssetsIntoHTML"));
var _HTMLTransformation = _interopRequireDefault(require("./plugins/HTMLTransformation"));
var _optionalRequire, _configuration$cache$, _configuration$cache, _configuration$cache2, _configuration$cache3;
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2["default"])(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t["return"] || t["return"](); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
/// region optional imports
// NOTE: Has to be defined here to ensure to resolve from here.
var currentRequire =
/*
    typeof __non_webpack_require__ === 'function' ?
        __non_webpack_require__ :
*/
eval("typeof require === 'undefined' ? null : require");
var optionalRequire = exports.optionalRequire = function optionalRequire(id) {
  try {
    return currentRequire ? currentRequire(id) : null;
  } catch (_unused) {
    return null;
  }
};
var postcssCSSnano = optionalRequire('cssnano');
var postcssFontpath = optionalRequire('postcss-fontpath');
var postcssImport = optionalRequire('postcss-import');
var postcssSprites = optionalRequire('postcss-sprites');
var updateRule = (_optionalRequire = optionalRequire('postcss-sprites/lib/core')) === null || _optionalRequire === void 0 ? void 0 : _optionalRequire.updateRule;
var postcssURL = optionalRequire('postcss-url');
/// endregion
var pluginNameResourceMapping = {
  Favicon: 'favicons-webpack-plugin',
  ImageMinimizer: 'image-minimizer-webpack-plugin',
  HTML: 'html-webpack-plugin',
  MiniCSSExtract: 'mini-css-extract-plugin',
  offline: 'workbox-webpack-plugin',
  Terser: 'terser-webpack-plugin'
};
var plugins = {};
for (var _i = 0, _Object$entries = Object.entries(pluginNameResourceMapping); _i < _Object$entries.length; _i++) {
  var _Object$entries$_i = (0, _slicedToArray2["default"])(_Object$entries[_i], 2),
    name = _Object$entries$_i[0],
    alias = _Object$entries$_i[1];
  var plugin = optionalRequire(alias);
  if (plugin) plugins[name] = plugin;else console.debug("Optional webpack plugin \"".concat(name, "\" not available."));
}
// endregion
var configuration = (0, _configurator["default"])();
var _module = configuration.module;
// region initialisation
/// region determine library name
var libraryName;
if (configuration.libraryName) libraryName = configuration.libraryName;else if (Object.keys(configuration.injection.entry.normalized).length > 1) libraryName = '[name]';else {
  libraryName = configuration.name;
  if (['assign', 'global', 'this', 'var', 'window'].includes(configuration.exportFormat.self)) libraryName = (0, _clientnode.convertToValidVariableName)(libraryName);
}
if (libraryName === '*') libraryName = ['assign', 'global', 'this', 'var', 'window'].includes(configuration.exportFormat.self) ? Object.keys(configuration.injection.entry.normalized).map(function (name) {
  return (0, _clientnode.convertToValidVariableName)(name);
}) : undefined;
/// endregion
/// region plugins
var pluginInstances = [];
//// region define modules to ignore
var _iterator = _createForOfIteratorHelper([].concat(configuration.injection.ignorePattern)),
  _step;
try {
  for (_iterator.s(); !(_step = _iterator.n()).done;) {
    var pattern = _step.value;
    if (typeof pattern.contextRegExp === 'string') pattern.contextRegExp = new RegExp(pattern.contextRegExp);
    if (typeof pattern.resourceRegExp === 'string') pattern.resourceRegExp = new RegExp(pattern.resourceRegExp);
    pluginInstances.push(new _webpack.IgnorePlugin(pattern));
  }
  //// endregion
  //// region define modules to replace
} catch (err) {
  _iterator.e(err);
} finally {
  _iterator.f();
}
var _loop = function _loop() {
  var _Object$entries2$_i = (0, _slicedToArray2["default"])(_Object$entries2[_i2], 2),
    source = _Object$entries2$_i[0],
    replacement = _Object$entries2$_i[1];
  var search = new RegExp(source);
  pluginInstances.push(new _webpack.NormalModuleReplacementPlugin(search, function (resource) {
    resource.request = resource.request.replace(search, replacement);
  }));
};
for (var _i2 = 0, _Object$entries2 = Object.entries(_module.replacements.normal); _i2 < _Object$entries2.length; _i2++) {
  _loop();
}
//// endregion
//// region generate html file
var htmlAvailable = false;
if (plugins.HTML) {
  var _iterator2 = _createForOfIteratorHelper(configuration.files.html),
    _step2;
  try {
    for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
      var htmlConfiguration = _step2.value;
      if ((0, _clientnode.isFileSync)(htmlConfiguration.template.filePath)) {
        pluginInstances.push(new plugins.HTML(_objectSpread(_objectSpread({}, htmlConfiguration), {}, {
          template: htmlConfiguration.template.request
        })));
        htmlAvailable = true;
      }
    }
  } catch (err) {
    _iterator2.e(err);
  } finally {
    _iterator2.f();
  }
}
//// endregion
//// region generate favicons
if (htmlAvailable && Object.prototype.hasOwnProperty.call(configuration, 'favicon') && plugins.Favicon && (0, _clientnode.isFileSync)([].concat(configuration.favicon.logo)[0])) pluginInstances.push(new plugins.Favicon(configuration.favicon));
//// endregion
//// region provide offline functionality
if (htmlAvailable && configuration.offline && Object.prototype.hasOwnProperty.call(plugins, 'offline')) {
  if (!['serve', 'test:browser'].includes(configuration.givenCommandLineArguments[2])) for (var _i3 = 0, _Object$entries3 = Object.entries({
      cascadingStyleSheet: 'css',
      javaScript: 'js'
    }); _i3 < _Object$entries3.length; _i3++) {
    var _Object$entries3$_i = (0, _slicedToArray2["default"])(_Object$entries3[_i3], 2),
      _name = _Object$entries3$_i[0],
      extension = _Object$entries3$_i[1];
    var type = _name;
    if (configuration.inPlace[type]) {
      var matches = Object.keys(configuration.inPlace[type]);
      if (!Array.isArray(configuration.offline.common.excludeChunks)) configuration.offline.common.excludeChunks = [];
      for (var _i4 = 0, _matches = matches; _i4 < _matches.length; _i4++) {
        var _name2 = _matches[_i4];
        configuration.offline.common.excludeChunks.push((0, _path.relative)(configuration.path.target.base, configuration.path.target.asset[type]) + "".concat(_name2, ".").concat(extension, "?").concat(configuration.hashAlgorithm, "=*"));
      }
    }
  }
  if (plugins.offline) {
    if ([].concat(configuration.offline.use).includes('injectionManifest')) pluginInstances.push(new plugins.offline.InjectManifest((0, _clientnode.extend)(true, configuration.offline.common, configuration.offline.injectionManifest)));
    if ([].concat(configuration.offline.use).includes('generateServiceWorker')) pluginInstances.push(new plugins.offline.GenerateSW((0, _clientnode.extend)(true, configuration.offline.common, configuration.offline.generateServiceWorker)));
  }
}
//// endregion
//// region provide build environment
if (Object.prototype.hasOwnProperty.call(configuration.buildContext, 'definitions')) pluginInstances.push(new _webpack.DefinePlugin(configuration.buildContext.definitions));
if (_module.provide) pluginInstances.push(new _webpack.ProvidePlugin(_module.provide));
//// endregion
//// region modules/assets
///// region apply module pattern
pluginInstances.push({
  apply: function apply(compiler) {
    var name = 'ApplyModulePattern';
    compiler.hooks.compilation.tap(name, function (compilation) {
      compilation.hooks.processAssets.tap({
        name: name,
        additionalAssets: true,
        stage: _webpack.Compilation.PROCESS_ASSETS_STAGE_ADDITIONS
      }, function (assets) {
        for (var _i5 = 0, _Object$entries4 = Object.entries(assets); _i5 < _Object$entries4.length; _i5++) {
          var _Object$entries4$_i = (0, _slicedToArray2["default"])(_Object$entries4[_i5], 2),
            request = _Object$entries4$_i[0],
            asset = _Object$entries4$_i[1];
          var filePath = request.replace(/\?[^?]+$/, '');
          var _type = (0, _helper.determineAssetType)(filePath, configuration.buildContext.types, configuration.path);
          if (_type && Object.prototype.hasOwnProperty.call(configuration.assetPattern, _type) && new RegExp(configuration.assetPattern[_type].includeFilePathRegularExpression).test(filePath) && !new RegExp(configuration.assetPattern[_type].excludeFilePathRegularExpression).test(filePath)) {
            var source = asset.source();
            if (typeof source === 'string') compilation.assets[request] = new _webpackSources.RawSource(configuration.assetPattern[_type].pattern.replace(/\{1\}/g, source.replace(/\$/g, '$$$')));
          }
        }
      });
    });
  }
});
///// endregion
///// region in-place configured assets in the main html file
/*
    TODO

    /
        NOTE: We have to translate template delimiter to html compatible
        sequences and translate it back later to avoid unexpected escape
        sequences in resulting html.
    /
    const window: DOMWindow = (new DOM(
        content
            .replace(/<%/g, '##+#+#+##')
            .replace(/%>/g, '##-#-#-##')
    )).window

    ->

    .replace(/##\+#\+#\+##/g, '<%')
    .replace(/##-#-#-##/g, '%>')
*/

if (plugins.HTML && htmlAvailable && !['serve', 'test:browser'].includes(configuration.givenCommandLineArguments[2]) && configuration.inPlace.cascadingStyleSheet && Object.keys(configuration.inPlace.cascadingStyleSheet).length || configuration.inPlace.javaScript && Object.keys(configuration.inPlace.javaScript).length) pluginInstances.push(new _InPlaceAssetsIntoHTML["default"]({
  cascadingStyleSheet: configuration.inPlace.cascadingStyleSheet,
  javaScript: configuration.inPlace.javaScript,
  htmlPlugin: plugins.HTML
}));
///// endregion
///// region mark empty javaScript modules as dummy
if (!(configuration.needed.javaScript || configuration.needed.javaScriptExtension || configuration.needed.typeScript || configuration.needed.typeScriptExtension)) configuration.files.compose.javaScript = (0, _path.resolve)(configuration.path.target.asset.javaScript, '.__dummy__.compiled.js');
///// endregion
///// region extract cascading style sheets
var cssOutputPath = configuration.files.compose.cascadingStyleSheet;
if (cssOutputPath && plugins.MiniCSSExtract) pluginInstances.push(new plugins.MiniCSSExtract({
  filename: typeof cssOutputPath === 'string' ? (0, _path.relative)(configuration.path.target.base, cssOutputPath) : cssOutputPath
}));
///// endregion
///// region performs implicit external logic
if (configuration.injection.external.modules === '__implicit__')
  /*
      We only want to process modules from local context in library mode,
      since a concrete project using this library should combine all assets
      (and de-duplicate them) for optimal bundling results.
      NOTE: Only native javascript and json modules will be marked as
      external dependency.
  */
  configuration.injection.external.modules = function (_ref, callback) {
    var context = _ref.context,
      request = _ref.request;
    if (typeof request !== 'string') {
      callback();
      return;
    }
    request = request.replace(/^!+/, '');
    if (request.startsWith('/')) request = (0, _path.relative)(configuration.path.context, request);
    var _iterator3 = _createForOfIteratorHelper(_module.directoryNames),
      _step3;
    try {
      for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
        var _filePath = _step3.value;
        if (request.startsWith(_filePath)) {
          request = request.substring(_filePath.length);
          if (request.startsWith('/')) request = request.substring(1);
          break;
        }
      }
      // region pattern based aliasing
    } catch (err) {
      _iterator3.e(err);
    } finally {
      _iterator3.f();
    }
    var filePath = (0, _helper.determineModuleFilePath)(request, {}, {}, {
      file: configuration.extensions.file.external
    }, configuration.path.context, context, configuration.path.ignore, _module.directoryNames, configuration["package"].main.fileNames, configuration["package"].main.propertyNames, configuration["package"].aliasPropertyNames, configuration.encoding);
    if (filePath) for (var _i6 = 0, _Object$entries5 = Object.entries(configuration.injection.external.aliases); _i6 < _Object$entries5.length; _i6++) {
      var _Object$entries5$_i = (0, _slicedToArray2["default"])(_Object$entries5[_i6], 2),
        pattern = _Object$entries5$_i[0],
        targetConfiguration = _Object$entries5$_i[1];
      if (targetConfiguration && pattern.startsWith('^')) {
        var regularExpression = new RegExp(pattern);
        if (regularExpression.test(filePath)) {
          var match = false;
          var firstKey = Object.keys(targetConfiguration)[0];
          var target = targetConfiguration[firstKey];
          if (typeof target !== 'string') break;
          var replacementRegularExpression = new RegExp(firstKey);
          if (target.startsWith('?')) {
            target = target.substring(1);
            var aliasedRequest = request.replace(replacementRegularExpression, target);
            if (aliasedRequest !== request) match = Boolean((0, _helper.determineModuleFilePath)(aliasedRequest, {}, {}, {
              file: configuration.extensions.file.external
            }, configuration.path.context, context, configuration.path.ignore, _module.directoryNames, configuration["package"].main.fileNames, configuration["package"].main.propertyNames, configuration["package"].aliasPropertyNames, configuration.encoding));
          } else match = true;
          if (match) {
            request = request.replace(replacementRegularExpression, target);
            break;
          }
        }
      }
    }
    // endregion
    var resolvedRequest = (0, _helper.determineExternalRequest)(request, configuration.path.context, context, configuration.injection.entry.normalized, _module.directoryNames, _module.aliases, _module.replacements.normal, configuration.extensions, configuration.path.source.asset.base, configuration.path.ignore, _module.directoryNames, configuration["package"].main.fileNames, configuration["package"].main.propertyNames, configuration["package"].aliasPropertyNames, configuration.injection.external.implicit.pattern.include, configuration.injection.external.implicit.pattern.exclude, configuration.inPlace.externalLibrary.normal, configuration.inPlace.externalLibrary.dynamic, configuration.encoding);
    if (resolvedRequest) {
      var keys = ['amd', 'commonjs', 'commonjs2', 'root'];
      var result = resolvedRequest;
      if (Object.prototype.hasOwnProperty.call(configuration.injection.external.aliases, request)) {
        // region normal alias replacement
        result = {
          "default": request
        };
        if (typeof configuration.injection.external.aliases[request] === 'string') {
          var _iterator4 = _createForOfIteratorHelper(keys),
            _step4;
          try {
            for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
              var key = _step4.value;
              result[key] = configuration.injection.external.aliases[request];
            }
          } catch (err) {
            _iterator4.e(err);
          } finally {
            _iterator4.f();
          }
        } else if (typeof configuration.injection.external.aliases[request] === 'function') {
          var _iterator5 = _createForOfIteratorHelper(keys),
            _step5;
          try {
            for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
              var _key2 = _step5.value;
              result[_key2] = configuration.injection.external.aliases[request](request, _key2);
            }
          } catch (err) {
            _iterator5.e(err);
          } finally {
            _iterator5.f();
          }
        } else if ((0, _clientnode.isObject)(configuration.injection.external.aliases[request])) (0, _clientnode.extend)(result, configuration.injection.external.aliases[request]);
        if (Object.prototype.hasOwnProperty.call(result, 'default')) {
          var _iterator6 = _createForOfIteratorHelper(keys),
            _step6;
          try {
            for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) {
              var _key3 = _step6.value;
              if (!Object.prototype.hasOwnProperty.call(result, _key3)) result[_key3] = result["default"];
            }
          } catch (err) {
            _iterator6.e(err);
          } finally {
            _iterator6.f();
          }
        }
        // endregion
      }
      if (typeof result !== 'string' && Object.prototype.hasOwnProperty.call(result, 'root') && Array.isArray(result.root)) result.root = [].concat(result.root).map(function (name) {
        return (0, _clientnode.convertToValidVariableName)(name);
      });
      var exportFormat = Object.prototype.hasOwnProperty.call(configuration.exportFormat, 'external') ? configuration.exportFormat.external : configuration.exportFormat.self;
      callback(undefined, exportFormat === 'umd' || typeof result === 'string' ? result : result[exportFormat], exportFormat);
      return;
    }
    callback();
  };
///// endregion
//// endregion
//// region apply final html modifications/fixes
if (htmlAvailable && plugins.HTML) pluginInstances.push(new _HTMLTransformation["default"]({
  hashAlgorithm: configuration.hashAlgorithm,
  htmlPlugin: plugins.HTML,
  files: configuration.files.html
}));
//// endregion
//// region context replacements
var _iterator7 = _createForOfIteratorHelper(_module.replacements.context),
  _step7;
try {
  for (_iterator7.s(); !(_step7 = _iterator7.n()).done;) {
    var contextReplacement = _step7.value;
    pluginInstances.push((0, _construct2["default"])(_webpack.ContextReplacementPlugin, (0, _toConsumableArray2["default"])(contextReplacement.map(function (value) {
      var evaluated = (0, _clientnode.evaluate)(value, {
        configuration: configuration,
        __dirname: __dirname,
        __filename: __filename
      });
      if (evaluated.error) throw new Error('Error occurred during processing given context ' + "replacement: ".concat(evaluated.error));
      return evaluated.result;
    }))));
  }
  //// endregion
  //// region consolidate duplicated module requests
  /*
      NOTE: Redundancies usually occur when symlinks aren't converted to their
      real paths since real paths can be de-duplicated by webpack but if two
      linked modules share the same transitive dependency webpack wont recognize
      them as same dependency.
  */
} catch (err) {
  _iterator7.e(err);
} finally {
  _iterator7.f();
}
if (_module.enforceDeduplication) {
  var absoluteContextPath = (0, _path.resolve)(configuration.path.context);
  var consolidator = function consolidator(result) {
    var targetPath = result.createData.resource;
    if (targetPath && /((?: ^|\/)node_modules\/.+)/.test(targetPath) && (!targetPath.startsWith(absoluteContextPath) || /((?: ^|\/)node_modules\/.+){2}/.test(targetPath)) && (0, _clientnode.isFileSync)(targetPath)) {
      var packageDescriptor = (0, _helper.getClosestPackageDescriptor)(targetPath);
      if (packageDescriptor) {
        var pathPrefixes;
        var pathSuffix;
        if (targetPath.startsWith(absoluteContextPath)) {
          var _matches2 = targetPath.match(/((?: ^|.*?\/)node_modules\/)/g);
          if (_matches2 === null) return;
          pathPrefixes = Array.from(_matches2);
          /*
              Remove last one to avoid replacing with the already set
              path.
          */
          pathPrefixes.pop();
          var index = 0;
          var _iterator8 = _createForOfIteratorHelper(pathPrefixes),
            _step8;
          try {
            for (_iterator8.s(); !(_step8 = _iterator8.n()).done;) {
              var pathPrefix = _step8.value;
              if (index > 0) pathPrefixes[index] = (0, _path.resolve)(pathPrefixes[index - 1], pathPrefix);
              index += 1;
            }
          } catch (err) {
            _iterator8.e(err);
          } finally {
            _iterator8.f();
          }
          pathSuffix = targetPath.replace(/(?: ^|.*\/)node_modules\/(.+$)/, '$1');
        } else {
          pathPrefixes = [(0, _path.resolve)(absoluteContextPath, 'node_modules')];
          // Find longest common prefix.
          var _index = 0;
          while (_index < absoluteContextPath.length && absoluteContextPath.charAt(_index) === targetPath.charAt(_index)) _index += 1;
          pathSuffix = targetPath.substring(_index).replace(/^.*\/node_modules\//, '');
        }
        var redundantRequest = null;
        var _iterator9 = _createForOfIteratorHelper(pathPrefixes),
          _step9;
        try {
          for (_iterator9.s(); !(_step9 = _iterator9.n()).done;) {
            var _pathPrefix = _step9.value;
            var alternateTargetPath = (0, _path.resolve)(_pathPrefix, pathSuffix);
            if ((0, _clientnode.isFileSync)(alternateTargetPath)) {
              var otherPackageDescriptor = (0, _helper.getClosestPackageDescriptor)(alternateTargetPath);
              if (otherPackageDescriptor) {
                if (packageDescriptor.configuration.version === otherPackageDescriptor.configuration.version) {
                  console.info('\nConsolidate module request "' + "".concat(targetPath, "\" to \"") + "".concat(alternateTargetPath, "\"."));
                  /*
                      NOTE: Only overwriting
                      "result.createData.resource" like
                      implemented in
                      "NormaleModuleReplacementPlugin" does
                      not always work.
                  */
                  result.request = result.createData.rawRequest = result.createData.request = result.createData.resource = result.createData.userRequest = alternateTargetPath;
                  return;
                }
                redundantRequest = {
                  path: alternateTargetPath,
                  version: otherPackageDescriptor.configuration.version
                };
              }
            }
          }
        } catch (err) {
          _iterator9.e(err);
        } finally {
          _iterator9.f();
        }
        if (redundantRequest) console.warn('\nIncluding different versions of same package "' + "".concat(packageDescriptor.configuration.name, "\". Module \"") + "".concat(targetPath, "\" (version ") + "".concat(packageDescriptor.configuration.version, ") has ") + "redundancies with \"".concat(redundantRequest.path, "\" (") + "version ".concat(redundantRequest.version, ")."));
      }
    }
  };
  pluginInstances.push({
    apply: function apply(compiler) {
      compiler.hooks.normalModuleFactory.tap('WebOptimizerModuleConsolidation', function (nmf) {
        nmf.hooks.afterResolve.tap('WebOptimizerModuleConsolidation', consolidator);
      });
    }
  });
}
/*
new NormalModuleReplacementPlugin(
    /.+/,
    (result: {
        context: string
        createData: {resource: string}
        request: string
    }): void => {
        const isResource: boolean = Boolean(result.createData.resource)
        const targetPath: string = isResource ?
            result.createData.resource :
            resolve(result.context, result.request)
        if (
            targetPath &&
            /((?: ^|\/)node_modules\/.+){2}/.test(targetPath) &&
            isFileSync(targetPath)
        ) {
            const packageDescriptor: null | PackageDescriptor =
                Helper.getClosestPackageDescriptor(targetPath)
            if (packageDescriptor) {
                const pathPrefixes: null | RegExpMatchArray = targetPath.match(
                    /((?: ^|.*?\/)node_modules\/)/g
                )
                if (pathPrefixes === null)
                    return
                // Avoid finding the same artefact.
                pathPrefixes.pop()
                let index: number = 0
                for (const pathPrefix of pathPrefixes) {
                    if (index > 0)
                        pathPrefixes[index] =
                            resolve(pathPrefixes[index - 1], pathPrefix)
                    index += 1
                }
                const pathSuffix: string =
                    targetPath.replace(/(?: ^|.*\/)node_modules\/(.+$)/, '$1')
                let redundantRequest: null | PlainObject = null
                for (const pathPrefix of pathPrefixes) {
                    const alternateTargetPath: string =
                        resolve(pathPrefix, pathSuffix)
                    if (isFileSync(alternateTargetPath)) {
                        const otherPackageDescriptor: null | PackageDescriptor =
                            Helper.getClosestPackageDescriptor(
                                alternateTargetPath
                            )
                        if (otherPackageDescriptor) {
                            if (
                                packageDescriptor.configuration.version ===
                                otherPackageDescriptor.configuration.version
                            ) {
                                console.info(
                                    '\nConsolidate module request "' +
                                    `${targetPath}" to "` +
                                    `${alternateTargetPath}".`
                                )
                                result.createData.resource =
                                    alternateTargetPath
                                result.request = alternateTargetPath
                                return
                            }
                            redundantRequest = {
                                path: alternateTargetPath,
                                version:
                                    otherPackageDescriptor.configuration
                                        .version
                            }
                        }
                    }
                }
                if (redundantRequest)
                    console.warn(
                        '\nIncluding different versions of same package "' +
                        `${packageDescriptor.configuration.name}". Module "` +
                        `${targetPath}" (version ` +
                        `${packageDescriptor.configuration.version}) has ` +
                        `redundancies with "${redundantRequest.path}" (` +
                        `version ${redundantRequest.version}).`
                    )
            }
        }
    }
))*/
//// endregion
/// endregion
/// region loader helper
var isFilePathInDependencies = function isFilePathInDependencies(filePath) {
  filePath = (0, _helper.stripLoader)(filePath);
  return (0, _helper.isFilePathInLocation)(filePath, configuration.path.ignore.concat(_module.directoryNames, configuration.loader.directoryNames).map(function (filePath) {
    return (0, _path.resolve)(configuration.path.context, filePath);
  }).filter(function (filePath) {
    return !configuration.path.context.startsWith(filePath);
  }));
};
var loader = {};
var scope = {
  configuration: configuration,
  isFilePathInDependencies: isFilePathInDependencies,
  loader: loader,
  require: currentRequire !== null && currentRequire !== void 0 ? currentRequire : require
};
var evaluateAnThrow = function evaluateAnThrow(object) {
  var givenOptions = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var options = _objectSpread({
    filePath: configuration.path.context
  }, givenOptions);
  if (typeof object === 'string') {
    var evaluated = (0, _clientnode.evaluate)(object, _objectSpread(_objectSpread({
      filePath: options.filePath
    }, scope), {}, {
      type: options.type
    }));
    if (evaluated.error) throw new Error('Error occurred during processing given expression: ' + evaluated.error);
    return evaluated.result;
  }
  return object;
};
var createEvaluateMapper = function createEvaluateMapper(type) {
  return function (value) {
    return evaluateAnThrow(value, {
      type: type
    });
  };
};
var evaluateAdditionalLoaderConfiguration = function evaluateAdditionalLoaderConfiguration(loaderConfiguration) {
  return {
    exclude: function exclude(filePath) {
      return evaluateAnThrow(loaderConfiguration.exclude, {
        filePath: filePath
      });
    },
    include: loaderConfiguration.include && evaluateAnThrow(loaderConfiguration.include) || configuration.path.source.base,
    test: new RegExp(evaluateAnThrow(loaderConfiguration.test)),
    use: evaluateAnThrow(loaderConfiguration.use)
  };
};
var getIncludingPaths = function getIncludingPaths(path) {
  return (0, _helper.normalizePaths)([path].concat(_module.locations.directoryPaths));
};
var cssUse = _module.preprocessor.cascadingStyleSheet.additional.pre.map(createEvaluateMapper('css')).concat({
  loader: _module.style.loader,
  options: _module.style.options || {}
}, {
  loader: _module.cascadingStyleSheet.loader,
  options: _module.cascadingStyleSheet.options || {}
}, _module.preprocessor.cascadingStyleSheet.loader ? {
  loader: _module.preprocessor.cascadingStyleSheet.loader,
  options: (0, _clientnode.extend)(true, optionalRequire('postcss') ? {
    postcssOptions: {
      /*
          NOTE: Some plugins like "postcss-import" are
          not yet ported to postcss 8. Let the final
          consumer decide which distribution suites most.
      */
      plugins: [].concat(postcssImport ? postcssImport({
        root: configuration.path.context
      }) : [], _module.preprocessor.cascadingStyleSheet.additional.plugins.pre.map(createEvaluateMapper('css.postcss')),
      /*
          NOTE: Checking path doesn't work if fonts
          are referenced in libraries provided in
          another location than the project itself
          like the "node_modules" folder.
      */
      postcssFontpath ? postcssFontpath({
        checkPath: false,
        formats: [{
          ext: 'woff2',
          type: 'woff2'
        }, {
          ext: 'woff',
          type: 'woff'
        }]
      }) : [], postcssURL ? postcssURL({
        url: 'rebase'
      }) : [], postcssSprites ? postcssSprites({
        filterBy: function filterBy() {
          return new Promise(function (resolve, reject) {
            (configuration.files.compose.image ? resolve : reject)();
          });
        },
        hooks: {
          onSaveSpritesheet: function onSaveSpritesheet(image) {
            return (0, _path.join)(image.spritePath, (0, _path.relative)(configuration.path.target.asset.image, configuration.files.compose.image));
          },
          /*
              Reset this token due to a
              sprite bug with
              "background-image" declaration
              which do not refer to an image
              (e.g. linear gradient instead).
          */
          onUpdateRule: function onUpdateRule(rule, token, image) {
            if (updateRule) if (token.value.includes(token.text)) updateRule(rule, token, image);else token.cloneAfter({
              type: 'decl',
              prop: 'background-' + 'image',
              value: token.value
            });
          }
        },
        stylesheetPath: configuration.path.source.asset.cascadingStyleSheet,
        spritePath: configuration.path.source.asset.image
      }) : [], _module.preprocessor.cascadingStyleSheet.additional.plugins.post.map(createEvaluateMapper('css.postcss')), _module.optimizer.cssnano && postcssCSSnano ? postcssCSSnano(_module.optimizer.cssnano) : [])
    }
  } : {}, _module.preprocessor.cascadingStyleSheet.options || {})
} : [], _module.preprocessor.cascadingStyleSheet.additional.post.map(createEvaluateMapper('css')));
var genericLoader = {
  // Convert to compatible native web types.
  // region generic template
  ejs: {
    exclude: function exclude(filePath) {
      return (0, _helper.normalizePaths)(configuration.files.html.concat(configuration.files.defaultHTML).map(function (htmlConfiguration) {
        return htmlConfiguration.template.filePath;
      })).includes(filePath) || _module.preprocessor.ejs.exclude === null ? false : evaluateAnThrow(_module.preprocessor.ejs.exclude, {
        filePath: filePath
      });
    },
    include: getIncludingPaths(configuration.path.source.asset.template),
    test: /^(?!.+\.html\.ejs$).+\.ejs$/i,
    use: _module.preprocessor.ejs.additional.pre.map(createEvaluateMapper('ejs')).concat({
      loader: _module.preprocessor.ejs.loader,
      options: (0, _clientnode.extend)(true, _module.preprocessor.ejs.options || {}, {
        compress: {
          html: false
        }
      })
    }, _module.preprocessor.ejs.additional.post.map(createEvaluateMapper('ejs')))
  },
  // endregion
  // region script
  script: {
    exclude: function exclude(filePath) {
      return evaluateAnThrow(_module.preprocessor.javaScript.exclude, {
        filePath: filePath,
        type: 'script'
      });
    },
    include: function include(filePath) {
      var result = evaluateAnThrow(_module.preprocessor.javaScript.include, {
        filePath: filePath,
        type: 'script'
      });
      if ([null, undefined].includes(result)) {
        var _iterator0 = _createForOfIteratorHelper(getIncludingPaths(configuration.path.source.asset.javaScript)),
          _step0;
        try {
          for (_iterator0.s(); !(_step0 = _iterator0.n()).done;) {
            var includePath = _step0.value;
            if (filePath.startsWith(includePath)) return true;
          }
        } catch (err) {
          _iterator0.e(err);
        } finally {
          _iterator0.f();
        }
        return false;
      }
      return Boolean(result);
    },
    test: new RegExp(_module.preprocessor.javaScript.regularExpression, 'i'),
    use: _module.preprocessor.javaScript.additional.pre.map(createEvaluateMapper('script')).concat({
      loader: _module.preprocessor.javaScript.loader,
      options: _module.preprocessor.javaScript.options || {}
    }, _module.preprocessor.javaScript.additional.post.map(createEvaluateMapper('script')))
  },
  // endregion
  // region html template
  html: {
    // NOTE: This is only for the main entry template.
    main: {
      test: new RegExp('^' + (0, _clientnode.escapeRegularExpressions)(configuration.files.defaultHTML.template.filePath) + '(?:\\?.*)?$'),
      use: configuration.files.defaultHTML.template.use
    },
    ejs: {
      exclude: function exclude(filePath) {
        return (0, _helper.normalizePaths)(configuration.files.html.concat(configuration.files.defaultHTML).map(function (htmlConfiguration) {
          return htmlConfiguration.template.filePath;
        })).includes(filePath) || (_module.preprocessor.html.exclude === null ? false : evaluateAnThrow(_module.preprocessor.html.exclude, {
          filePath: filePath,
          type: 'html.ejs'
        }));
      },
      include: configuration.path.source.asset.template,
      test: /\.html\.ejs(?:\?.*)?$/i,
      use: _module.preprocessor.html.additional.pre.map(createEvaluateMapper('html.ejs')).concat(
      /*
          We might need to evaluate ejs before we are able to
          parse html beforhand. If not we parse it as html
          directly.
      */

      ((0, _clientnode.isPlainObject)(_module.preprocessor.html.options) ? _module.preprocessor.html.options : {
        compileSteps: 2
      }).compileSteps % 2 ? [] : [{
        loader: 'extract'
      }, {
        loader: _module.html.loader,
        options: _module.html.options || {}
      }], {
        loader: _module.preprocessor.html.loader,
        options: _module.preprocessor.html.options || {}
      }, _module.preprocessor.html.additional.post.map(createEvaluateMapper('html.ejs')))
    },
    html: {
      exclude: function exclude(filePath) {
        return (0, _helper.normalizePaths)(configuration.files.html.concat(configuration.files.defaultHTML).map(function (htmlConfiguration) {
          return htmlConfiguration.template.filePath;
        })).includes(filePath) || (_module.html.exclude === null ? true : evaluateAnThrow(_module.html.exclude, {
          filePath: filePath,
          type: 'html'
        }));
      },
      include: configuration.path.source.asset.template,
      test: /\.html(?:\?.*)?$/i,
      use: _module.html.additional.pre.map(createEvaluateMapper('html')).concat({
        loader: 'file?name=' + (0, _path.join)((0, _path.relative)(configuration.path.target.base, configuration.path.target.asset.template), "[name][ext]?".concat(configuration.hashAlgorithm, "=") + '[contenthash]')
      }, {
        loader: 'extract'
      }, {
        loader: _module.html.loader,
        options: _module.html.options || {}
      }, _module.html.additional.post.map(createEvaluateMapper('html')))
    }
  },
  // endregion
  // Load dependencies.
  // region style
  style: {
    exclude: function exclude(filePath) {
      return _module.cascadingStyleSheet.exclude === null ? isFilePathInDependencies(filePath) : evaluateAnThrow(_module.cascadingStyleSheet.exclude, {
        filePath: filePath,
        type: 'style'
      });
    },
    include: function include(filePath) {
      var result = evaluateAnThrow(_module.cascadingStyleSheet.include, {
        filePath: filePath,
        type: 'style'
      });
      if ([null, undefined].includes(result)) {
        var _iterator1 = _createForOfIteratorHelper(getIncludingPaths(configuration.path.source.asset.cascadingStyleSheet)),
          _step1;
        try {
          for (_iterator1.s(); !(_step1 = _iterator1.n()).done;) {
            var includePath = _step1.value;
            if (filePath.startsWith(includePath)) return true;
          }
        } catch (err) {
          _iterator1.e(err);
        } finally {
          _iterator1.f();
        }
        return false;
      }
      return Boolean(result);
    },
    test: /\.s?css(?: \?.*)?$/i,
    use: cssUse
  },
  // endregion
  // Optimize loaded assets.
  // region font
  font: {
    eot: {
      exclude: function exclude(filePath) {
        return _module.optimizer.font.eot.exclude === null ? false : evaluateAnThrow(_module.optimizer.font.eot.exclude, {
          filePath: filePath,
          type: 'font.eot'
        });
      },
      generator: {
        filename: (0, _path.join)((0, _path.relative)(configuration.path.target.base, configuration.path.target.asset.font), '[name][ext]') + "?".concat(configuration.hashAlgorithm, "=[contenthash]")
      },
      test: /\.eot(?: \?.*)?$/i,
      type: 'asset/resource',
      parser: {
        dataUrlCondition: {
          maxSize: configuration.inPlace.otherMaximumFileSizeLimitInByte
        }
      },
      use: _module.optimizer.font.eot.loader.map(createEvaluateMapper('font.eot'))
    },
    svg: {
      exclude: function exclude(filePath) {
        return _module.optimizer.font.svg.exclude === null ? false : evaluateAnThrow(_module.optimizer.font.svg.exclude, {
          filePath: filePath,
          type: 'svg'
        });
      },
      include: configuration.path.source.asset.font,
      generator: {
        filename: (0, _path.join)((0, _path.relative)(configuration.path.target.base, configuration.path.target.asset.font), '[name][ext]') + "?".concat(configuration.hashAlgorithm, "=[contenthash]")
      },
      mimetype: 'image/svg+xml',
      parser: {
        dataUrlCondition: {
          maxSize: configuration.inPlace.otherMaximumFileSizeLimitInByte
        }
      },
      test: /\.svg(?: \?.*)?$/i,
      type: 'asset/resource',
      use: _module.optimizer.font.svg.loader.map(createEvaluateMapper('font.svg'))
    },
    ttf: {
      exclude: function exclude(filePath) {
        return _module.optimizer.font.ttf.exclude === null ? false : evaluateAnThrow(_module.optimizer.font.ttf.exclude, {
          filePath: filePath,
          type: 'ttf'
        });
      },
      generator: {
        filename: (0, _path.join)((0, _path.relative)(configuration.path.target.base, configuration.path.target.asset.font), '[name][ext]') + "?".concat(configuration.hashAlgorithm, "=[contenthash]")
      },
      test: /\.ttf(?: \?.*)?$/i,
      type: 'asset/resource',
      mimetype: 'application/octet-stream',
      parser: {
        dataUrlCondition: {
          maxSize: configuration.inPlace.otherMaximumFileSizeLimitInByte
        }
      },
      use: _module.optimizer.font.ttf.loader.map(createEvaluateMapper('font.ttf'))
    },
    woff: {
      exclude: function exclude(filePath) {
        return _module.optimizer.font.woff.exclude === null ? false : evaluateAnThrow(_module.optimizer.font.woff.exclude, {
          filePath: filePath,
          type: 'woff'
        });
      },
      generator: {
        filename: (0, _path.join)((0, _path.relative)(configuration.path.target.base, configuration.path.target.asset.font), '[name][ext]') + "?".concat(configuration.hashAlgorithm, "=[contenthash]")
      },
      test: /\.woff2?(?: \?.*)?$/i,
      type: 'asset/resource',
      parser: {
        dataUrlCondition: {
          maxSize: configuration.inPlace.otherMaximumFileSizeLimitInByte
        }
      },
      use: _module.optimizer.font.woff.loader.map(createEvaluateMapper('font.woff'))
    }
  },
  // endregion
  // region image
  image: {
    exclude: function exclude(filePath) {
      return _module.optimizer.image.exclude === null ? isFilePathInDependencies(filePath) : evaluateAnThrow(_module.optimizer.image.exclude, {
        filePath: filePath,
        type: 'image'
      });
    },
    generator: {
      filename: (0, _path.join)((0, _path.relative)(configuration.path.target.base, configuration.path.target.asset.image), '[name][ext]') + "?".concat(configuration.hashAlgorithm, "=[contenthash]")
    },
    include: configuration.path.source.asset.image,
    test: /\.(?: gif|ico|jpg|png|svg)(?: \?.*)?$/i,
    type: 'asset/resource',
    parser: {
      dataUrlCondition: {
        maxSize: configuration.inPlace.otherMaximumFileSizeLimitInByte
      }
    },
    use: _module.optimizer.image.loader.map(createEvaluateMapper('image'))
  },
  // endregion
  // region data
  data: {
    exclude: function exclude(filePath) {
      if (typeof filePath !== 'string') return false;
      return configuration.extensions.file.internal.includes((0, _path.extname)((0, _helper.stripLoader)(filePath))) || (_module.optimizer.data.exclude === null ? isFilePathInDependencies(filePath) : evaluateAnThrow(_module.optimizer.data.exclude, {
        filePath: filePath,
        type: 'data'
      }));
    },
    generator: {
      filename: (0, _path.join)((0, _path.relative)(configuration.path.target.base, configuration.path.target.asset.data), '[name][ext]') + "?".concat(configuration.hashAlgorithm, "=[contenthash]")
    },
    test: /.+/,
    type: 'asset/resource',
    parser: {
      dataUrlCondition: {
        maxSize: configuration.inPlace.otherMaximumFileSizeLimitInByte
      }
    },
    use: _module.optimizer.data.loader.map(createEvaluateMapper('data'))
  }
  // endregion
};
(0, _clientnode.extend)(loader, genericLoader);
if (configuration.files.compose.cascadingStyleSheet && plugins.MiniCSSExtract) {
  /*
      NOTE: We have to remove the client side javascript hmr style loader
      first.
  */
  loader.style.use.shift();
  loader.style.use.unshift({
    loader: plugins.MiniCSSExtract.loader
  });
}
/// endregion
/// region apply runtime dev helper
/*
    NOTE: Disable automatic injection to avoid injection in all chunks and as
    last module which would shadow main module (e.g. index).
    So we inject live reload and hot module replacement manually.
*/
if (htmlAvailable && configuration.debug && configuration.development.server.liveReload && !Object.prototype.hasOwnProperty.call(configuration.injection.entry.normalized, 'developmentHandler') && (configuration.development.includeClient || typeof configuration.development.includeClient !== 'boolean' && ['serve', 'test:browser'].includes(configuration.givenCommandLineArguments[2]))) {
  configuration.injection.entry.normalized.developmentHandler = ['webpack-dev-server/client/index.js?' + 'live-reload=true' + "&hot=".concat(configuration.development.server.hot ? 'true' : 'false') + "&http".concat(configuration.development.server.https ? 's' : '', "://") + "".concat(configuration.development.server.host, ": ") + String(configuration.development.server.port)];
  if (configuration.development.server.hot) {
    configuration.injection.entry.normalized.developmentHandler.push('webpack/hot/dev-server.js');
    configuration.development.server.hot = false;
    pluginInstances.push(new _webpack.HotModuleReplacementPlugin());
  }
}
/// endregion
// endregion
// region plugins
var _iterator10 = _createForOfIteratorHelper(configuration.plugins),
  _step10;
try {
  for (_iterator10.s(); !(_step10 = _iterator10.n()).done;) {
    var pluginConfiguration = _step10.value;
    var _plugin = optionalRequire(pluginConfiguration.name.module);
    if (_plugin) pluginInstances.push((0, _construct2["default"])(_plugin[pluginConfiguration.name.initializer], (0, _toConsumableArray2["default"])(pluginConfiguration.parameters)));else console.warn("Configured plugin module \"".concat(pluginConfiguration.name.module, "\" ") + 'could not be loaded.');
  }
  // endregion
  // region minimizer and image compression
  // NOTE: This plugin should be loaded at last to ensure that all emitted images
  // ran through.
} catch (err) {
  _iterator10.e(err);
} finally {
  _iterator10.f();
}
if (!_module.optimizer.minimizer) {
  _module.optimizer.minimizer = [];
  if (plugins.Terser) _module.optimizer.minimizer.push(new plugins.Terser({
    extractComments: false,
    parallel: true
  }));
  if (plugins.ImageMinimizer) _module.optimizer.minimizer.push(new plugins.ImageMinimizer((0, _clientnode.extend)(true, {
    minimizer: {
      implementation: plugins.ImageMinimizer.imageminMinify
    }
  }, _module.optimizer.image.content)));
}
// endregion
// region configuration
var customConfiguration = {};
if (configuration.path.configuration.json) try {
  require.resolve(configuration.path.configuration.json);
  try {
    customConfiguration = currentRequire(configuration.path.configuration.json);
  } catch (error) {
    console.debug('Importing provided json webpack configuration file path ' + "under \"".concat(configuration.path.configuration.json, "\" failed: ") + (0, _clientnode.represent)(error));
  }
} catch (_unused2) {
  console.debug('Optional configuration file "' + "".concat(configuration.path.configuration.json, "\" not available."));
}
var webpackConfiguration = exports.webpackConfiguration = (0, _clientnode.extend)(true, {
  bail: !configuration.givenCommandLineArguments.includes('--watch'),
  context: configuration.path.context,
  devtool: configuration.development.tool,
  devServer: configuration.development.server,
  experiments: {
    topLevelAwait: true
  },
  // region input
  entry: configuration.injection.entry.normalized,
  externals: configuration.injection.external.modules,
  resolve: {
    alias: _module.aliases,
    aliasFields: configuration["package"].aliasPropertyNames,
    extensions: configuration.extensions.file.internal,
    mainFields: configuration["package"].main.propertyNames,
    mainFiles: configuration["package"].main.fileNames,
    modules: (0, _helper.normalizePaths)(_module.directoryNames),
    symlinks: _module.resolveSymlinks,
    unsafeCache: Boolean((_configuration$cache$ = (_configuration$cache = configuration.cache) === null || _configuration$cache === void 0 ? void 0 : _configuration$cache.unsafe) !== null && _configuration$cache$ !== void 0 ? _configuration$cache$ : (_configuration$cache2 = configuration.cache) === null || _configuration$cache2 === void 0 ? void 0 : _configuration$cache2.main)
  },
  resolveLoader: {
    alias: configuration.loader.aliases,
    aliasFields: configuration["package"].aliasPropertyNames,
    extensions: configuration.loader.extensions.file,
    mainFields: configuration["package"].main.propertyNames,
    mainFiles: configuration["package"].main.fileNames,
    modules: configuration.loader.directoryNames,
    symlinks: configuration.loader.resolveSymlinks
  },
  // endregion
  // region output
  output: {
    assetModuleFilename: (0, _path.join)((0, _path.relative)(configuration.path.target.base, configuration.path.target.asset.base), '[name][ext]') + "?".concat(configuration.hashAlgorithm, "=[chunkhash]"),
    filename: (0, _path.relative)(configuration.path.target.base, configuration.files.compose.javaScript),
    globalObject: configuration.exportFormat.globalObject,
    hashFunction: configuration.hashAlgorithm,
    library: {
      name: libraryName,
      type: configuration.exportFormat.self,
      umdNamedDefine: true
    },
    path: configuration.path.target.base,
    publicPath: configuration.path.target["public"]
  },
  performance: configuration.performanceHints,
  /*
      NOTE: Live-reload is not working if target technology is not set to
      "web". Webpack boilerplate code may not support target
      technologies.
  */
  target: configuration.targetTechnology.boilerplate,
  // endregion
  mode: configuration.debug ? 'development' : 'production',
  module: {
    rules: _module.additional.pre.map(evaluateAdditionalLoaderConfiguration).concat(loader.ejs, loader.script, loader.html.main, loader.html.ejs, loader.html.html, loader.style, loader.font.eot, loader.font.svg, loader.font.ttf, loader.font.woff, loader.image, loader.data, _module.additional.post.map(evaluateAdditionalLoaderConfiguration))
  },
  node: configuration.nodeEnvironment,
  optimization: _objectSpread({
    chunkIds: configuration.debug ? 'named' : 'total-size',
    moduleIds: configuration.debug ? 'named' : 'size',
    // region common chunks
    splitChunks: (0, _clientnode.extend)(true, !configuration.injection.chunks || configuration.targetTechnology.payload === 'node' || configuration.givenCommandLineArguments[2] === 'test' ? {
      cacheGroups: {
        "default": false,
        defaultVendors: false
      }
    } : {
      chunks: 'all',
      cacheGroups: {
        defaultVendors: {
          chunks: function chunks(chunk) {
            if (configuration.inPlace.javaScript) for (var _i7 = 0, _Object$keys = Object.keys(configuration.inPlace.javaScript); _i7 < _Object$keys.length; _i7++) {
              var _name3 = _Object$keys[_i7];
              if (_name3 === '*' || _name3 === chunk.name) return false;
            }
            return true;
          },
          priority: -10,
          reuseExistingChunk: true,
          test: /[\\/]node_modules[\\/]/
        }
      }
    }, configuration.injection.chunks)
  }, (0, _clientnode.mask)(_module.optimizer, {
    exclude: {
      babelMinify: true,
      cssnano: true,
      data: true,
      font: true,
      htmlMinifier: true,
      image: true
    }
  })),
  plugins: pluginInstances
}, (_configuration$cache3 = configuration.cache) !== null && _configuration$cache3 !== void 0 && _configuration$cache3.main ? {
  cache: configuration.cache.main
} : {}, configuration.webpack, customConfiguration);
if (configuration.nodeENV !== null) if ((0, _typeof2["default"])(webpackConfiguration.optimization) === 'object') webpackConfiguration.optimization.nodeEnv = configuration.nodeENV;else webpackConfiguration.optimization = {
  nodeEnv: configuration.nodeENV
};
if (!Array.isArray(_module.skipParseRegularExpressions) || _module.skipParseRegularExpressions.length) if ((0, _typeof2["default"])(webpackConfiguration.module) === 'object') webpackConfiguration.module.noParse = _module.skipParseRegularExpressions;else webpackConfiguration.module = {
  noParse: _module.skipParseRegularExpressions
};
if (configuration.path.configuration.javaScript) try {
  require.resolve(configuration.path.configuration.javaScript);
  var result = optionalRequire(configuration.path.configuration.javaScript);
  if ((0, _clientnode.isPlainObject)(result)) {
    if (Object.prototype.hasOwnProperty.call(result, 'replaceWebOptimizer')) exports.webpackConfiguration = webpackConfiguration = result.replaceWebOptimizer;else (0, _clientnode.extend)(true, webpackConfiguration, result);
  } else console.debug('Failed to load given JavaScript configuration file path "' + "".concat(configuration.path.configuration.javaScript, "\"."));
} catch (_unused3) {
  console.debug('Optional configuration file script "' + "".concat(configuration.path.configuration.javaScript, "\" not available."));
}
if (configuration.showConfiguration) {
  console.info('Using internal configuration: ', _util["default"].inspect(configuration, {
    depth: null
  }));
  console.info('-----------------------------------------------------------');
  console.info('Using webpack configuration: ', _util["default"].inspect(webpackConfiguration, {
    depth: null
  }));
}
// endregion
var _default = exports["default"] = webpackConfiguration;
