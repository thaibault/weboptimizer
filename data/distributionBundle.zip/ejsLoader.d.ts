import type { Encoding, Mapping } from 'clientnode';
import type { Options, AsyncTemplateFunction as EJSAsyncTemplateFunction } from 'ejs';
import type { LoaderContext } from 'webpack';
import type { Extensions, Replacements } from './type';
import { Logger } from 'clientnode';
export type TemplateFunction = EJSAsyncTemplateFunction;
export type CompilerOptions = Options & {
    encoding: Encoding;
    isString?: boolean;
};
export type CompileFunction = (template: string, options?: Partial<CompilerOptions>, compileSteps?: number) => TemplateFunction;
export type LoaderConfiguration = Mapping<unknown> & {
    compiler: Partial<CompilerOptions>;
    compileSteps: number;
    compress: {
        html: Mapping<unknown>;
        javaScript: boolean;
    };
    context: string;
    debug: boolean;
    extensions: Extensions;
    locals?: Mapping<unknown>;
    module: {
        aliases: Mapping;
        replacements: Replacements;
    };
    pathsToIgnore: Array<string>;
};
export declare const log: Logger;
/**
 * Main transformation function.
 * @param source - Input string to transform.
 * @returns Transformed string.
 */
export declare const loader: (this: (Partial<LoaderContext<LoaderConfiguration>> & {
    async: (result: unknown) => void;
}), source: string) => Promise<void>;
export default loader;
