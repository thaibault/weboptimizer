import { Encoding, Logger, Mapping } from 'clientnode';
import { Options, TemplateFunction as EJSTemplateFunction } from 'ejs';
import { LoaderContext } from 'webpack';
import { Extensions, Replacements } from './type';
export type TemplateFunction = EJSTemplateFunction;
export type CompilerOptions = Options & {
    encoding: Encoding;
    isString?: boolean;
};
export type CompileFunction = (template: string, options?: Partial<CompilerOptions>, compileSteps?: number) => TemplateFunction;
export type LoaderConfiguration = Mapping<unknown> & {
    compiler: Partial<CompilerOptions>;
    compileSteps: number;
    compress: {
        html: Mapping<unknown>;
        javaScript: Mapping<unknown>;
    };
    context: string;
    debug: boolean;
    extensions: Extensions;
    locals?: Mapping<unknown>;
    module: {
        aliases: Mapping;
        replacements: Replacements;
    };
};
export declare const log: Logger;
/**
 * Main transformation function.
 * @param source - Input string to transform.
 * @returns Transformed string.
 */
export declare const loader: (this: Partial<LoaderContext<LoaderConfiguration>>, source: string) => string;
export default loader;
