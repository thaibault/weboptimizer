import { Encoding, Mapping } from 'clientnode/type';
import { Options, TemplateFunction as EJSTemplateFunction } from 'ejs';
import { LoaderContext } from 'webpack';
import { Extensions, Replacements } from './type';
export declare type PreCompiledTemplateFunction = ((..._parameters: Array<unknown>) => string);
export declare type TemplateFunction = EJSTemplateFunction | PreCompiledTemplateFunction;
export declare type CompilerOptions = Options & {
    encoding: Encoding;
    isString?: boolean;
};
export declare type CompileFunction = (_template: string, _options?: Partial<CompilerOptions>, _compileSteps?: number) => TemplateFunction;
export declare type LoaderConfiguration = Mapping<unknown> & {
    compiler: Partial<CompilerOptions>;
    compileSteps: number;
    compress: {
        html: Mapping<unknown>;
        javaScript: Mapping<unknown>;
    };
    context: string;
    debug: boolean;
    extensions: Extensions;
    locals?: Mapping<unknown>;
    module: {
        aliases: Mapping<string>;
        replacements: Replacements;
    };
};
/**
 * Main transformation function.
 * @param this - Loader context.
 * @param source - Input string to transform.
 *
 * @returns Transformed string.
 */
export declare const loader: (this: LoaderContext<LoaderConfiguration>, source: string) => string;
export default loader;
