/**
 * Checks if given path points to a valid file.
 * @param filePath - Path to directory.
 * @returns A promise holding a boolean which indicates directory existence.
 */
export declare const isFile: (filePath: string) => Promise<boolean>;
export declare const config: import("@typescript-eslint/utils/dist/ts-eslint").FlatConfig.ConfigArray;
export default config;
