import type { WebpackConfiguration } from './type';
import { Logger } from 'clientnode';
export declare const log: Logger;
export declare let webpackConfiguration: WebpackConfiguration;
export default webpackConfiguration;
