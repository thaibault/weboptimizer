import { WebpackConfiguration } from './type';
export declare let webpackConfiguration: WebpackConfiguration;
export default webpackConfiguration;
