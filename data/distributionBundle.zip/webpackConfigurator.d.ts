import { WebpackConfiguration } from './type';
export declare const optionalRequire: <T = unknown>(id: string) => T | null;
export declare let webpackConfiguration: WebpackConfiguration;
export default webpackConfiguration;
