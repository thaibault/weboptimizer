import { WebpackConfiguration } from './type';
export declare const optionalRequire: <T = unknown>(id: string) => null | T;
export declare let webpackConfiguration: WebpackConfiguration;
export default webpackConfiguration;
