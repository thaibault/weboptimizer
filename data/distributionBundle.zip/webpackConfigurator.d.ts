import { Logger } from 'clientnode';
import { WebpackConfiguration } from './type';
export declare const log: Logger;
export declare const optionalRequire: <T = unknown>(id: string) => null | T;
export declare let webpackConfiguration: WebpackConfiguration;
export default webpackConfiguration;
