/// <reference types="node" />
/// <reference types="webpack-env" />
/// <reference types="node" />
/// <reference types="node" />
/// <reference types="node" />
/// <reference types="node" />
import { ResolvedConfiguration } from './type';
export declare let loadedConfiguration: null | ResolvedConfiguration;
/**
 * Main entry point to determine current configuration.
 * @param context - Location from where to build current application.
 * @param currentWorkingDirectory - Current working directory to use as
 * reference.
 * @param commandLineArguments - Arguments to take into account.
 * @param webOptimizerPath - Current optimizer context path.
 * @param environment - Environment variables to take into account.
 *
 * @returns Nothing.
 */
export declare const load: (context?: string, currentWorkingDirectory?: string, commandLineArguments?: Array<string>, webOptimizerPath?: string, environment?: NodeJS.ProcessEnv) => ResolvedConfiguration;
/**
 * Get cached or determined configuration object.
 * @returns Nothing.
 */
export declare const get: () => ResolvedConfiguration;
export default get;
