import { Compiler } from 'webpack';
import { HTMLTransformationOptions } from '../type';
export declare class HTMLTransformation {
    private defaultOptions;
    private options;
    constructor(options?: Partial<HTMLTransformationOptions>);
    private process;
    apply(compiler: Compiler): void;
}
export default HTMLTransformation;
