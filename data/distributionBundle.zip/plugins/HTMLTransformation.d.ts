import type { Compiler } from 'webpack';
import type { HTMLTransformationOptions } from '../type';
export declare class HTMLTransformation {
    private defaultOptions;
    private options;
    constructor(options?: Partial<HTMLTransformationOptions>);
    private process;
    apply(compiler: Compiler): void;
}
export default HTMLTransformation;
