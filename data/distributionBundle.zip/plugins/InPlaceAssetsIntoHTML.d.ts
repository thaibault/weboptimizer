import { Compiler } from 'webpack';
import { InPlaceAssetsIntoHTMLOptions } from '../type';
export declare class InPlaceAssetsIntoHTML {
    private defaultOptions;
    private options;
    constructor(options?: Partial<InPlaceAssetsIntoHTMLOptions>);
    apply(compiler: Compiler): void;
}
export default InPlaceAssetsIntoHTML;
