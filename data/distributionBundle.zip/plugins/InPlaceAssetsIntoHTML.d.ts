import type { Compiler } from 'webpack';
import type { InPlaceAssetsIntoHTMLOptions } from '../type';
export declare class InPlaceAssetsIntoHTML {
    private defaultOptions;
    private options;
    constructor(options?: Partial<InPlaceAssetsIntoHTMLOptions>);
    apply(compiler: Compiler): void;
}
export default InPlaceAssetsIntoHTML;
