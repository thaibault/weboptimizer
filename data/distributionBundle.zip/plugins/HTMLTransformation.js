// #!/usr/bin/env babel-node
// -*- coding: utf-8 -*-
/** @module InPlaceAssetsIntoHTML */
'use strict';

/* !
    region header
    Copyright Torben Sickert (info["~at~"]tsickert.com) 16.12.2012

    License
    -------

    This library written by Torben Sickert stands under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/
// region imports
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import { copy, extend } from 'clientnode';
import HtmlWebpackPlugin from 'html-webpack-plugin';
import { JSDOM as DOM } from 'jsdom';
import ejsLoader from "../ejsLoader.js";
// endregion

export class HTMLTransformation {
  constructor(options = {}) {
    _defineProperty(this, "defaultOptions", {});
    _defineProperty(this, "options", void 0);
    this.options = {
      ...this.defaultOptions,
      ...options
    };
  }
  async process(data) {
    /*
        NOTE: We have to prevent creating native "style" dom nodes to
        prevent jsdom from parsing the entire cascading style sheet. Which
        is error prune and very resource intensive.
    */
    const styleContents = [];
    data.html = data.html.replace(/(<style[^>]*>)([\s\S]*?)(<\/style[^>]*>)/gi, (match, startTag, content, endTag) => {
      styleContents.push(content);
      return `${startTag}${endTag}`;
    });
    let dom;
    try {
      /*
          NOTE: We have to translate template delimiter to html
          compatible sequences and translate it back later to avoid
          unexpected escape sequences in resulting html.
      */
      dom = new DOM(data.html.replace(/<%/g, '##+#+#+##').replace(/%>/g, '##-#-#-##'));
    } catch {
      return data;
    }
    const linkables = {
      link: 'href',
      script: 'src'
    };
    for (const [tagName, attributeName] of Object.entries(linkables)) for (const domNode of Array.from(dom.window.document.querySelectorAll(`${tagName}[${attributeName}*="?` + `${this.options.hashAlgorithm}="]`))) {
      /*
          NOTE: Removing symbols after a "&" in hash string is
          necessary to match the generated request strings in offline
          plugin.
      */
      const value = domNode.getAttribute(attributeName);
      if (value) domNode.setAttribute(attributeName, value.replace(new RegExp(`(\\?${this.options.hashAlgorithm}=[^&]+).*$`), '$1'));
    }
    // NOTE: We have to restore template delimiter and style contents.
    data.html = dom.serialize().replace(/##\+#\+#\+##/g, '<%').replace(/##-#-#-##/g, '%>').replace(/(<style[^>]*>)[\s\S]*?(<\/style[^>]*>)/gi, (match, startTag, endTag) => `${startTag}${styleContents.shift()}${endTag}`);
    // region post compilation
    for (const htmlFileSpecification of this.options.files) if (htmlFileSpecification.filename === data.plugin.options.filename) {
      for (const loaderConfiguration of [].concat(htmlFileSpecification.template.use)) if (loaderConfiguration.options?.compileSteps && typeof loaderConfiguration.options.compileSteps === 'number') data.html = await new Promise((resolve, reject) => {
        void ejsLoader.bind({
          query: extend(true, Object.prototype.hasOwnProperty.call(loaderConfiguration, 'options') ? copy(loaderConfiguration.options) : {}, htmlFileSpecification.template.postCompileOptions),
          async: () => (error, result) => {
            if (error) reject(error);else resolve(result);
          }
        })(data.html);
      });
      break;
    }
    // endregion
    return data;
  }
  apply(compiler) {
    compiler.hooks.compilation.tap('WebOptimizer', compilation => {
      this.options.htmlPlugin.getHooks(compilation).beforeEmit.tapPromise('WebOptimizerPostProcessHTML', this.process.bind(this));
    });
  }
}
export default HTMLTransformation;
