// #!/usr/bin/env babel-node
// -*- coding: utf-8 -*-
/** @module InPlaceAssetsIntoHTML */
'use strict';

/* !
    region header
    Copyright Torben Sickert (info["~at~"]torben.website) 16.12.2012

    License
    -------

    This library written by Torben Sickert stand under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/
// region imports
var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = exports.HTMLTransformation = void 0;
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));
var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _clientnode = require("clientnode");
var _jsdom = require("jsdom");
var _ejsLoader = _interopRequireDefault(require("../ejsLoader"));
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t["return"] || t["return"](); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2["default"])(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
// endregion
var HTMLTransformation = exports.HTMLTransformation = /*#__PURE__*/function () {
  function HTMLTransformation() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    (0, _classCallCheck2["default"])(this, HTMLTransformation);
    (0, _defineProperty2["default"])(this, "defaultOptions", {});
    this.options = _objectSpread(_objectSpread({}, this.defaultOptions), options);
  }
  return (0, _createClass2["default"])(HTMLTransformation, [{
    key: "process",
    value: function process(data) {
      /*
          NOTE: We have to prevent creating native "style" dom nodes to
          prevent jsdom from parsing the entire cascading style sheet. Which
          is error prune and very resource intensive.
      */
      var styleContents = [];
      data.html = data.html.replace(/(<style[^>]*>)([\s\S]*?)(<\/style[^>]*>)/gi, function (match, startTag, content, endTag) {
        styleContents.push(content);
        return "".concat(startTag).concat(endTag);
      });
      var dom;
      try {
        /*
            NOTE: We have to translate template delimiter to html
            compatible sequences and translate it back later to avoid
            unexpected escape sequences in resulting html.
        */
        dom = new _jsdom.JSDOM(data.html.replace(/<%/g, '##+#+#+##').replace(/%>/g, '##-#-#-##'));
      } catch (_unused) {
        return data;
      }
      var linkables = {
        link: 'href',
        script: 'src'
      };
      for (var _i = 0, _Object$entries = Object.entries(linkables); _i < _Object$entries.length; _i++) {
        var _Object$entries$_i = (0, _slicedToArray2["default"])(_Object$entries[_i], 2),
          tagName = _Object$entries$_i[0],
          attributeName = _Object$entries$_i[1];
        for (var _i2 = 0, _Array$from = Array.from(dom.window.document.querySelectorAll("".concat(tagName, "[").concat(attributeName, "*=\"?") + "".concat(this.options.hashAlgorithm, "=\"]"))); _i2 < _Array$from.length; _i2++) {
          var domNode = _Array$from[_i2];
          /*
              NOTE: Removing symbols after a "&" in hash string is
              necessary to match the generated request strings in offline
              plugin.
          */
          var value = domNode.getAttribute(attributeName);
          if (value) domNode.setAttribute(attributeName, value.replace(new RegExp("(\\?".concat(this.options.hashAlgorithm, "=[^&]+).*$")), '$1'));
        }
      }
      // NOTE: We have to restore template delimiter and style contents.
      data.html = dom.serialize().replace(/##\+#\+#\+##/g, '<%').replace(/##-#-#-##/g, '%>').replace(/(<style[^>]*>)[\s\S]*?(<\/style[^>]*>)/gi, function (match, startTag, endTag) {
        return "".concat(startTag).concat(styleContents.shift()).concat(endTag);
      });
      // region post compilation
      var _iterator = _createForOfIteratorHelper(this.options.files),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var htmlFileSpecification = _step.value;
          if (htmlFileSpecification.filename === data.plugin.options.filename) {
            var _iterator2 = _createForOfIteratorHelper([].concat(htmlFileSpecification.template.use)),
              _step2;
            try {
              for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                var _loaderConfiguration$;
                var loaderConfiguration = _step2.value;
                if ((_loaderConfiguration$ = loaderConfiguration.options) !== null && _loaderConfiguration$ !== void 0 && _loaderConfiguration$.compileSteps && typeof loaderConfiguration.options.compileSteps === 'number') data.html = _ejsLoader["default"].bind({
                  query: (0, _clientnode.extend)(true, Object.prototype.hasOwnProperty.call(loaderConfiguration, 'options') ? (0, _clientnode.copy)(loaderConfiguration.options) : {}, htmlFileSpecification.template.postCompileOptions)
                })(data.html);
              }
            } catch (err) {
              _iterator2.e(err);
            } finally {
              _iterator2.f();
            }
            break;
          }
        }
        // endregion
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
      return data;
    }
  }, {
    key: "apply",
    value: function apply(compiler) {
      var _this = this;
      compiler.hooks.compilation.tap('WebOptimizer', function (compilation) {
        _this.options.htmlPlugin.getHooks(compilation).beforeEmit.tap('WebOptimizerPostProcessHTML', _this.process.bind(_this));
      });
    }
  }]);
}();
var _default = exports["default"] = HTMLTransformation;
