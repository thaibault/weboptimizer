// #!/usr/bin/env babel-node
// -*- coding: utf-8 -*-
/** @module InPlaceAssetsIntoHTML */
'use strict';

/* !
    region header
    Copyright Torben Sickert (info["~at~"]torben.website) 16.12.2012

    License
    -------

    This library written by Torben Sickert stands under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/
// region imports
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import HtmlWebpackPlugin from 'html-webpack-plugin';
// endregion

export class InPlaceAssetsIntoHTML {
  constructor(options = {}) {
    _defineProperty(this, "defaultOptions", {});
    _defineProperty(this, "options", void 0);
    this.options = {
      ...this.defaultOptions,
      ...options
    };
  }
  apply(compiler) {
    let publicPath = compiler.options.output.publicPath || '';
    if (publicPath && !publicPath.endsWith('/')) publicPath += '/';
    compiler.hooks.compilation.tap('inPlaceHTMLAssets', compilation => {
      const hooks = this.options.htmlPlugin.getHooks(compilation);
      const inPlacedAssetNames = [];
      hooks.alterAssetTagGroups.tap('inPlaceHTMLAssets', assets => {
        const inPlace = (type, tag) => {
          let settings = null;
          let url = false;
          if (tag.tagName === 'script') {
            settings = this.options.javaScript;
            url = tag.attributes.src;
          } else if (tag.tagName === 'style') {
            settings = this.options.cascadingStyleSheet;
            url = tag.attributes.href;
          }
          if (!(url && typeof url === 'string')) return tag;
          const name = publicPath ? url.replace(publicPath, '') : url;
          if (Object.prototype.hasOwnProperty.call(compilation.assets, name) && settings && settings[type] && [].concat(settings[type]).some(pattern => new RegExp(pattern).test(name))) {
            const newAttributes = {
              ...tag.attributes
            };
            delete newAttributes.href;
            delete newAttributes.src;
            inPlacedAssetNames.push(name);
            return {
              ...tag,
              attributes: newAttributes,
              innerHTML: compilation.assets[name].source(),
              tagName: 'script'
            };
          }
          return tag;
        };
        assets.headTags = assets.headTags.map(inPlace.bind(this, 'head'));
        assets.bodyTags = assets.bodyTags.map(inPlace.bind(this, 'body'));
        return assets;
      });

      // NOTE: Avoid if you still want to emit the runtime chunks:
      hooks.afterEmit.tap('inPlaceHTMLAssets', asset => {
        for (const name of inPlacedAssetNames) delete compilation.assets[name];
        return asset;
      });
    });
  }
}
export default InPlaceAssetsIntoHTML;
