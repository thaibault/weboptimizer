// #!/usr/bin/env babel-node
// -*- coding: utf-8 -*-
/** @module InPlaceAssetsIntoHTML */
'use strict';

/* !
    region header
    Copyright Torben Sickert (info["~at~"]torben.website) 16.12.2012

    License
    -------

    This library written by Torben Sickert stand under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/
// region imports
var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = exports.InPlaceAssetsIntoHTML = void 0;
var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));
var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2["default"])(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
// endregion
var InPlaceAssetsIntoHTML = exports.InPlaceAssetsIntoHTML = /*#__PURE__*/function () {
  function InPlaceAssetsIntoHTML() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    (0, _classCallCheck2["default"])(this, InPlaceAssetsIntoHTML);
    (0, _defineProperty2["default"])(this, "defaultOptions", {});
    this.options = _objectSpread(_objectSpread({}, this.defaultOptions), options);
  }
  return (0, _createClass2["default"])(InPlaceAssetsIntoHTML, [{
    key: "apply",
    value: function apply(compiler) {
      var _this = this;
      var publicPath = compiler.options.output.publicPath || '';
      if (publicPath && !publicPath.endsWith('/')) publicPath += '/';
      compiler.hooks.compilation.tap('inPlaceHTMLAssets', function (compilation) {
        var hooks = _this.options.htmlPlugin.getHooks(compilation);
        var inPlacedAssetNames = [];
        hooks.alterAssetTagGroups.tap('inPlaceHTMLAssets', function (assets) {
          var inPlace = function inPlace(type, tag) {
            var settings = null;
            var url = false;
            if (tag.tagName === 'script') {
              settings = _this.options.javaScript;
              url = tag.attributes.src;
            } else if (tag.tagName === 'style') {
              settings = _this.options.cascadingStyleSheet;
              url = tag.attributes.href;
            }
            if (!(url && typeof url === 'string')) return tag;
            var name = publicPath ? url.replace(publicPath, '') : url;
            if (Object.prototype.hasOwnProperty.call(compilation.assets, name) && settings && settings[type] && [].concat(settings[type]).some(function (pattern) {
              return new RegExp(pattern).test(name);
            })) {
              var newAttributes = _objectSpread({}, tag.attributes);
              delete newAttributes.href;
              delete newAttributes.src;
              inPlacedAssetNames.push(name);
              return _objectSpread(_objectSpread({}, tag), {}, {
                attributes: newAttributes,
                innerHTML: compilation.assets[name].source(),
                tagName: 'script'
              });
            }
            return tag;
          };
          assets.headTags = assets.headTags.map(inPlace.bind(_this, 'head'));
          assets.bodyTags = assets.bodyTags.map(inPlace.bind(_this, 'body'));
          return assets;
        });

        // NOTE: Avoid if you still want to emit the runtime chunks:
        hooks.afterEmit.tap('inPlaceHTMLAssets', function (asset) {
          for (var _i = 0, _inPlacedAssetNames = inPlacedAssetNames; _i < _inPlacedAssetNames.length; _i++) {
            var name = _inPlacedAssetNames[_i];
            delete compilation.assets[name];
          }
          return asset;
        });
      });
    }
  }]);
}();
var _default = exports["default"] = InPlaceAssetsIntoHTML;
