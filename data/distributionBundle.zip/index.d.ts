#!/usr/bin/env babel-node
/**
 * Main entry point.
 * @param context - Location from where to build current application.
 * @param currentWorkingDirectory - Current working directory to use as
 * reference.
 * @param commandLineArguments - Arguments to take into account.
 * @param webOptimizerPath - Current optimizer context path.
 * @param environment - Environment variables to take into account.
 * @returns Nothing.
 */
declare const main: (context?: string, currentWorkingDirectory?: string, commandLineArguments?: Array<string>, webOptimizerPath?: string, environment?: NodeJS.ProcessEnv) => Promise<() => void>;
export default main;
